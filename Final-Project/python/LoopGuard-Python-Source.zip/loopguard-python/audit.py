
from __future__ import annotations

import argparse
import json
from pathlib import Path

from loopguard import analyze
from loopguard.presentation import audit_markdown, fingerprint, parse_project, scenarios
from loopguard.tables import audit_tables, model_to_tables


def main() -> None:
    cases = {case["id"]: case for case in scenarios()}
    parser = argparse.ArgumentParser(description='Export a reproducible economy audit without starting Streamlit.')
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--scenario", choices=list(cases), default=None)
    source.add_argument("--project", type=Path, help="A saved loopguard-v1 JSON economy")
    parser.add_argument("--output", type=Path, default=Path("results"))
    parser.add_argument("--knime", action="store_true", help="Also execute the native KNIME decision workflow")
    args = parser.parse_args()
    model = parse_project(args.project.read_bytes()) if args.project else cases[args.scenario or "friendship-fair"]["model"]
    result = analyze(model)
    args.output.mkdir(parents=True, exist_ok=True)
    items, transactions = model_to_tables(model)
    frames = {"items": items, "transactions": transactions, **audit_tables(model)}
    for name, frame in frames.items():
        frame.to_csv(args.output / ("cycle_facts.csv" if name == "facts" else f"{name}.csv"), index=False)
    for name, data in (("project", model), ("analysis", result)):
        (args.output / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output / "audit.md").write_text(audit_markdown(model, result), encoding="utf-8")
    summary = {"model_sha256": fingerprint(model), "metrics": result["metrics"], "scope": result["scope"]}
    if args.knime:
        from knime.run_workflow import run_workflow
        native = run_workflow(model)
        native["comparison"].to_csv(args.output / "knime-comparison.csv", index=False)
        summary["knime"] = {key: native[key] for key in ("status", "executed", "matched", "fingerprint", "seconds")}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output.resolve()), **summary}, indent=2))


if __name__ == "__main__":
    main()
