# LoopGuard audit — Friendship Fair

Generated: 2026-10-25T10:08:25.812593+00:00

Model SHA-256: `7700c7d314f4039a3e5406d4ce5f2eff1a86135dc6d5b986d5faa742adca4995`

Unofficial classroom Sanrio concept; all economy data is fictional.


2 attention findings; 1 intentional rewards; 6 examined routes.


Search completed within the configured bounds.


## Friendship Gift return path

**Critical: repeatable profit** — The route earns currency and can repeat without an encoded cap or cooldown. This is a confirmed profit loop within the entered model.

Exact batch: 20 → 24 Friendship Coins; net +4; ROI +20%.

- **LG03 — Closed currency path:** 3 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 20 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG06 — Positive return:** 20 → 24 Friendship Coins. → Net gain 4; return 20%.

- **LG09 — No execution caps:** All caps are explicitly zero. → No execution cap is encoded.

- **LG12 — No cooldowns:** All cooldowns are explicitly zero. → No time delay is encoded.

- **LG21 — Unintended return:** Ribbon boutique, Gift wrapping workshop, Gift buyback counter → At least one transaction identifies this return as unintended.

- **LG24 — Repeatable profit:** Positive return + unintended label + explicitly absent limits. → The route earns currency and can repeat without an encoded cap or cooldown. This is a confirmed profit loop within the entered model.

- **LG31 — Buyback correction:** Gift buyback counter is the terminal payout. → A lower payout removes this route’s positive return; preview rechecks all enumerated routes.

- **LG30 — Output fee correction:** The terminal fee can absorb the excess return. → This route’s net return becomes nonpositive.

- **LG32 — Limit intervention:** No positive global cap is encoded. → A shared execution budget is an alternative throughput control, not a pricing fix.

- Possible intervention: Set Gift buyback counter output to 20 Friendship Coins per execution. This route becomes break-even or loss-making. Trade-off: Keeps the entry price and crafting recipe accessible; reduces resale or reward proceeds.

- Possible intervention: Set the Gift buyback counter output fee to 4 Friendship Coins per execution. Trade-off: Preserves the advertised gross payout but lowers what players actually receive.

- Possible intervention: Give Gift buyback counter a global cap of 3 executions per day. The pricing gain remains, but payout volume is bounded. Trade-off: A shared budget can be exhausted by early players. Use only if that distribution is intentional.


## Star Charm return path

**Needs attention** — The offer is limited per account, but its output is transferable. Investigate cross-account aggregation; an unlimited bypass is not established.

Exact batch: 8 → 12 Friendship Coins; net +4; ROI +50%.

- **LG03 — Closed currency path:** 3 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 8 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG06 — Positive return:** 8 → 12 Friendship Coins. → Net gain 4; return 50%.

- **LG10 — Finite execution cap:** Daily wish kiosk → At least one finite daily execution cap applies.

- **LG12 — No cooldowns:** All cooldowns are explicitly zero. → No time delay is encoded.

- **LG15 — Per-account allocation:** Daily wish kiosk → These caps are per account, not a shared economy-wide ceiling.

- **LG17 — Transferable allocation:** Daily wish kiosk → Outputs could be pooled across accounts; identity, ownership and transfer enforcement remain untested.

- **LG21 — Unintended return:** Daily wish kiosk, Starlight charm workshop, Charm collectors market → At least one transaction identifies this return as unintended.

- **LG26 — Account allocation risk:** Positive return + transferable account-capped output + no global cap. → The offer is limited per account, but its output is transferable. Investigate cross-account aggregation; an unlimited bypass is not established.

- **LG31 — Buyback correction:** Charm collectors market is the terminal payout. → A lower payout removes this route’s positive return; preview rechecks all enumerated routes.

- **LG30 — Output fee correction:** The terminal fee can absorb the excess return. → This route’s net return becomes nonpositive.

- **LG32 — Limit intervention:** No positive global cap is encoded. → A shared execution budget is an alternative throughput control, not a pricing fix.

- Evidence needed: Can one person aggregate these outputs across accounts, and does a server-side shared or identity-level restriction stop it?

- Possible intervention: Set Charm collectors market output to 8 Friendship Coins per execution. This route becomes break-even or loss-making. Trade-off: Keeps the entry price and crafting recipe accessible; reduces resale or reward proceeds.

- Possible intervention: Set the Charm collectors market output fee to 4 Friendship Coins per execution. Trade-off: Preserves the advertised gross payout but lowers what players actually receive.

- Possible intervention: Give Charm collectors market a global cap of 3 executions per day. The pricing gain remains, but payout volume is bounded. Trade-off: A shared budget can be exhausted by early players. Use only if that distribution is intentional.


## Cloud Latte return path

**Intentional reward** — This is an explicitly intended reward with a known throughput limit. Preserve it unless its budget is too high.

Exact batch: 10 → 14 Friendship Coins; net +4; ROI +40%.

- **LG03 — Closed currency path:** 3 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 10 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG06 — Positive return:** 10 → 14 Friendship Coins. → Net gain 4; return 40%.

- **LG10 — Finite execution cap:** Daily café orders → At least one finite daily execution cap applies.

- **LG13 — Cooldown bound:** Daily café orders → A cooldown limits steady full-day throughput.

- **LG16 — Shared allocation:** Daily café orders → A shared global allocation is explicitly encoded.

- **LG20 — Intended return:** All route transactions are marked intended. → The route has an explicit intended-reward interpretation.

- **LG28 — Bounded reward exception:** Positive return + intended labels + known finite limit. → This is an explicitly intended reward with a known throughput limit. Preserve it unless its budget is too high.


## Cloud Coffee Bean conversion path

**No positive gain** — Returns less than its entry cost after fees. No positive return was found on this route.

Exact batch: 5 → 4 Friendship Coins; net -1; ROI -20%.

- **LG03 — Closed currency path:** 2 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 5 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG08 — Loss-making path:** 5 → 4 Friendship Coins. → Net loss 1.

- **LG09 — No execution caps:** All caps are explicitly zero. → No execution cap is encoded.

- **LG12 — No cooldowns:** All cooldowns are explicitly zero. → No time delay is encoded.

- **LG20 — Intended return:** All route transactions are marked intended. → The route has an explicit intended-reward interpretation.


## Satin Ribbon conversion path

**No positive gain** — Returns less than its entry cost after fees. No positive return was found on this route.

Exact batch: 10 → 8 Friendship Coins; net -2; ROI -20%.

- **LG03 — Closed currency path:** 2 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 10 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG08 — Loss-making path:** 10 → 8 Friendship Coins. → Net loss 2.

- **LG09 — No execution caps:** All caps are explicitly zero. → No execution cap is encoded.

- **LG12 — No cooldowns:** All cooldowns are explicitly zero. → No time delay is encoded.

- **LG21 — Unintended return:** Ribbon boutique, Ribbon returns → At least one transaction identifies this return as unintended.


## Wish Stamp conversion path

**No positive gain** — Returns less than its entry cost after fees. No positive return was found on this route.

Exact batch: 8 → 6 Friendship Coins; net -2; ROI -25%.

- **LG03 — Closed currency path:** 2 transactions return to Friendship Coins. → A closed conversion route was found.

- **LG04 — Whole execution batches:** Minimum starting batch: 8 Friendship Coins. → Every step executes a whole number of times; no leftover assets are credited.

- **LG08 — Loss-making path:** 8 → 6 Friendship Coins. → Net loss 2.

- **LG10 — Finite execution cap:** Daily wish kiosk → At least one finite daily execution cap applies.

- **LG12 — No cooldowns:** All cooldowns are explicitly zero. → No time delay is encoded.

- **LG15 — Per-account allocation:** Daily wish kiosk → These caps are per account, not a shared economy-wide ceiling.

- **LG17 — Transferable allocation:** Daily wish kiosk → Outputs could be pooled across accounts; identity, ownership and transfer enforcement remain untested.

- **LG21 — Unintended return:** Daily wish kiosk, Unused stamp refund → At least one transaction identifies this return as unintended.


## Search scope

Simple currency-rooted cycles of up to six transactions; one input and one output per transaction. All conclusions depend on the supplied facts. Inventory, demand, identity enforcement, multiple-input recipes, and longer or compound cycles are outside this model. Daily bounds use whole batches from fresh inputs in one daily quota window; inventories may accumulate across days. Cooldowns apply per account, allowing an initially eligible execution in a 24-hour window. Account and global bounds are reported separately.


## Entered project

```json

{
  "schema": "loopguard-v1",
  "name": "Friendship Fair",
  "scenario": "friendship-fair",
  "items": [
    {
      "id": "coins",
      "name": "Friendship Coins",
      "kind": "currency",
      "icon": "✦"
    },
    {
      "id": "ribbon",
      "name": "Satin Ribbon",
      "kind": "material",
      "icon": "🎀"
    },
    {
      "id": "gift",
      "name": "Friendship Gift",
      "kind": "crafted",
      "icon": "🎁"
    },
    {
      "id": "stamp",
      "name": "Wish Stamp",
      "kind": "material",
      "icon": "✉"
    },
    {
      "id": "charm",
      "name": "Star Charm",
      "kind": "crafted",
      "icon": "★"
    },
    {
      "id": "bean",
      "name": "Cloud Coffee Bean",
      "kind": "material",
      "icon": "☁"
    },
    {
      "id": "latte",
      "name": "Cloud Latte",
      "kind": "crafted",
      "icon": "☕"
    }
  ],
  "transactions": [
    {
      "id": "ribbon-shop",
      "name": "Ribbon boutique",
      "from": "coins",
      "to": "ribbon",
      "input": 10,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Hello Kitty",
      "kind": "buy",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "gift-workshop",
      "name": "Gift wrapping workshop",
      "from": "ribbon",
      "to": "gift",
      "input": 2,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "My Melody",
      "kind": "craft",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "gift-buyback",
      "name": "Gift buyback counter",
      "from": "gift",
      "to": "coins",
      "input": 1,
      "output": 24,
      "fee": 0,
      "enabled": true,
      "character": "Hello Kitty",
      "kind": "sell",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "ribbon-return",
      "name": "Ribbon returns",
      "from": "ribbon",
      "to": "coins",
      "input": 1,
      "output": 8,
      "fee": 0,
      "enabled": true,
      "character": "Hello Kitty",
      "kind": "sell",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "gift-unpack",
      "name": "Unwrap a gift",
      "from": "gift",
      "to": "ribbon",
      "input": 1,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "My Melody",
      "kind": "exchange",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "wish-kiosk",
      "name": "Daily wish kiosk",
      "from": "coins",
      "to": "stamp",
      "input": 8,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Kuromi",
      "kind": "buy",
      "cooldown": 0,
      "cap": 2,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "charm-workshop",
      "name": "Starlight charm workshop",
      "from": "stamp",
      "to": "charm",
      "input": 1,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Kuromi",
      "kind": "craft",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "charm-buyback",
      "name": "Charm collectors market",
      "from": "charm",
      "to": "coins",
      "input": 1,
      "output": 12,
      "fee": 0,
      "enabled": true,
      "character": "Keroppi",
      "kind": "sell",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "stamp-return",
      "name": "Unused stamp refund",
      "from": "stamp",
      "to": "coins",
      "input": 1,
      "output": 6,
      "fee": 0,
      "enabled": true,
      "character": "Keroppi",
      "kind": "sell",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "charm-recycle",
      "name": "Charm recycling",
      "from": "charm",
      "to": "stamp",
      "input": 1,
      "output": 0.5,
      "fee": 0,
      "enabled": true,
      "character": "Kuromi",
      "kind": "exchange",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "unintended"
    },
    {
      "id": "coffee-supply",
      "name": "Cloud café ingredients",
      "from": "coins",
      "to": "bean",
      "input": 5,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Cinnamoroll",
      "kind": "buy",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "intended"
    },
    {
      "id": "latte-recipe",
      "name": "Brew a cloud latte",
      "from": "bean",
      "to": "latte",
      "input": 2,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Cinnamoroll",
      "kind": "craft",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "intended"
    },
    {
      "id": "cafe-orders",
      "name": "Daily café orders",
      "from": "latte",
      "to": "coins",
      "input": 1,
      "output": 14,
      "fee": 0,
      "enabled": true,
      "character": "Pompompurin",
      "kind": "reward",
      "cooldown": 60,
      "cap": 3,
      "capScope": "global",
      "transferable": false,
      "intent": "intended"
    },
    {
      "id": "bean-return",
      "name": "Surplus bean returns",
      "from": "bean",
      "to": "coins",
      "input": 1,
      "output": 4,
      "fee": 0,
      "enabled": true,
      "character": "Cinnamoroll",
      "kind": "sell",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "intended"
    },
    {
      "id": "latte-salvage",
      "name": "Latte salvage",
      "from": "latte",
      "to": "bean",
      "input": 1,
      "output": 1,
      "fee": 0,
      "enabled": true,
      "character": "Pompompurin",
      "kind": "exchange",
      "cooldown": 0,
      "cap": 0,
      "capScope": "account",
      "transferable": true,
      "intent": "intended"
    }
  ]
}

```