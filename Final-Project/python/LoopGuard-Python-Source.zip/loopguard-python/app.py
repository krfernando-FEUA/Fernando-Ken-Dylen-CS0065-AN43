




from __future__ import annotations

from copy import deepcopy
import io
import json

import pandas as pd
import streamlit as st

from loopguard import RULES, analyze, apply_patch, simulate, validate
from loopguard.presentation import (
    ROOT, VERDICTS, attention, audit_markdown, editor_tables, exchange_bundle,
    fingerprint, knime_workflow_bytes, model_from_editor, parse_project, route_dot, scenarios,
)

SCENARIOS = scenarios()
BY_SCENARIO = {scenario["id"]: scenario for scenario in SCENARIOS}
CHARACTERS = {
    "Hello Kitty": "hello-kitty", "My Melody": "my-melody", "Kuromi": "kuromi",
    "Cinnamoroll": "cinnamoroll", "Pompompurin": "pompompurin", "Keroppi": "keroppi",
}

st.set_page_config(page_title="LoopGuard · Friendship Fair", page_icon="🎀", layout="wide")


@st.cache_data(show_spinner=False)
def analyze_json(serialized: str) -> dict:
    return analyze(json.loads(serialized))


@st.cache_data(show_spinner=False)
def current_knime_archive(serialized: str) -> bytes:
    return knime_workflow_bytes(json.loads(serialized))


@st.cache_data(show_spinner=False)
def current_exchange_bundle(serialized: str) -> bytes:
    return exchange_bundle(json.loads(serialized))


def commit_model(candidate: dict, message: str) -> None:
    result = validate(candidate)
    if not result["valid"]:
        raise ValueError(" ".join(result["errors"]))
    st.session_state.history.append(deepcopy(st.session_state.model))
    st.session_state.history = st.session_state.history[-20:]
    st.session_state.model = deepcopy(candidate)
    st.session_state.revision += 1
    st.session_state.pop("knime_result", None)
    st.session_state.notice = message


def load_scenario() -> None:
    selected = BY_SCENARIO[st.session_state.scenario_id]
    commit_model(selected["model"], f"{selected['name']} loaded.")


def cycle_select(audit: dict, key: str) -> dict | None:
    choices = {cycle["id"]: cycle for cycle in audit["cycles"]}
    if not choices:
        st.info("No currency return routes are present. Add a return trade or load a scenario.")
        return None
    if st.session_state.get(key) not in choices:
        st.session_state.pop(key, None)
    chosen = st.selectbox("Route", list(choices), key=key,
                          format_func=lambda value: f"{choices[value]['title']} · {VERDICTS[choices[value]['severity']]}")
    return choices[chosen]


def show_verdict(cycle: dict) -> None:
    display = {"critical": st.error, "high": st.warning, "review": st.info,
               "intended": st.success, "healthy": st.success}[cycle["severity"]]
    display(f"**{VERDICTS[cycle['severity']]}**\n\n{cycle['summary']}")


def audit_view(model: dict, audit: dict) -> None:
    st.subheader("Audit the economy")
    metrics = st.columns(4)
    for column, label, value in zip(metrics, ("Need attention", "Intentional rewards", "Routes examined", "Active trades"),
                                    (attention(audit), audit["metrics"]["intended"], audit["metrics"]["cyclesAnalyzed"], audit["metrics"]["enabledTransactions"])):
        column.metric(label, value)
    rows = [{"Route": c["title"], "Decision": VERDICTS[c["severity"]], "Currency": c["currencyName"],
             "Starting amount": c["startAmount"], "Return": c["endAmount"], "Net gain": c["profit"], "ROI %": c["roi"]}
            for c in audit["cycles"]]
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    cycle = cycle_select(audit, "audit_cycle")
    if not cycle:
        return
    show_verdict(cycle)
    diagram, details = st.columns([2, 1])
    with diagram:
        st.graphviz_chart(route_dot(model, cycle), width="stretch")
        st.caption("Amounts are for the smallest complete batch. Every transaction executes a whole number of times.")
    with details:
        file = CHARACTERS.get(cycle["character"])
        if file:
            st.image(str(ROOT / "assets" / f"{file}.png"), width=70)
        st.markdown(f"**{cycle['character']}’s route**")
        st.metric(f"Net {cycle['currencyName']} per batch", f"{cycle['profit']:+g}", f"{cycle['roi']:+g}% return", delta_color="off")
        st.write(f"Starting funds: **{cycle['startAmount']:g}** · Return: **{cycle['endAmount']:g}**")
    st.markdown("#### Evidence and reasoning")
    facts = [{"Fact": fact["label"], "Evidence": str(fact["value"]) if fact["known"] else "Unknown — needs evidence"}
             for fact in cycle["facts"]]
    st.dataframe(pd.DataFrame(facts), hide_index=True, width="stretch")
    for question in cycle["questions"]:
        st.warning(question)
    with st.expander(f"Follow the {len(cycle['trace'])} fired rules", expanded=True):
        for entry in cycle["trace"]:
            st.markdown(f"**{entry['ruleId']} · {entry['label']}**")
            st.write(f"IF {entry['condition']}")
            st.caption(f"THEN {entry['conclusion']}")


def edit_view(model: dict) -> None:
    st.subheader("Edit shops, recipes, and rewards")
    st.caption("Save the table to recalculate every route. Empty cap/cooldown cells mean unknown; 0 explicitly means no restriction. Fees use output-item units.")
    items, trades = editor_tables(model)
    revision = st.session_state.revision
    with st.form("economy_form"):
        name = st.text_input("Economy name", value=model["name"], max_chars=100, key=f"economy_name_{revision}")
        with st.expander("Items and currencies", expanded=False):
            edited_items = st.data_editor(items, num_rows="dynamic", hide_index=True, width="stretch", key=f"items_editor_{revision}",
                column_config={"id": st.column_config.TextColumn("Item ID", required=True),
                               "name": st.column_config.TextColumn("Item name", required=True),
                               "kind": st.column_config.SelectboxColumn("Kind", options=["currency", "material", "crafted"], required=True),
                               "icon": st.column_config.TextColumn("Symbol")})
        edited_trades = st.data_editor(trades, num_rows="dynamic", hide_index=True, width="stretch", height=470,
            key=f"trades_editor_{revision}",
            column_order=["id", "name", "character", "enabled", "from", "input", "to", "output", "fee", "kind", "cap", "capScope", "cooldown", "transferable", "intent"],
            column_config={
                "id": st.column_config.TextColumn("Trade ID", required=True, help="Unique letters, digits, hyphens or underscores; starts with a letter/digit."),
                "name": st.column_config.TextColumn("Trade name", required=True),
                "character": st.column_config.TextColumn("Character", required=True),
                "from": st.column_config.TextColumn("Input item ID", required=True),
                "to": st.column_config.TextColumn("Output item ID", required=True),
                "input": st.column_config.NumberColumn("Input", min_value=.01, max_value=1_000_000, step=.01, required=True),
                "output": st.column_config.NumberColumn("Gross output", min_value=.01, max_value=1_000_000, step=.01, required=True),
                "fee": st.column_config.NumberColumn("Output fee", min_value=0, max_value=1_000_000, step=.01, required=True, default=0),
                "enabled": st.column_config.CheckboxColumn("Active", default=True, required=True),
                "kind": st.column_config.SelectboxColumn("Type", options=["buy", "craft", "sell", "exchange", "reward"], default="exchange", required=True),
                "cap": st.column_config.NumberColumn("Executions/day", min_value=0, max_value=1_000_000, step=1, help="Blank = unknown. Zero = unlimited."),
                "capScope": st.column_config.SelectboxColumn("Cap scope", options=["account", "global"], default="account", required=True),
                "cooldown": st.column_config.NumberColumn("Cooldown (minutes)", min_value=0, max_value=43_200, step=.01, help="Blank = unknown. Zero = none."),
                "transferable": st.column_config.SelectboxColumn("Output transferable?", options=["yes", "no", "unknown"], default="unknown", required=True),
                "intent": st.column_config.SelectboxColumn("Gain intended?", options=["unintended", "intended", "unknown"], default="unknown", required=True),
            })
        submitted = st.form_submit_button("Save & audit", type="primary")
    if submitted:
        try:
            candidate = model_from_editor(edited_items, edited_trades, name=name.strip(), scenario=model["scenario"])
            commit_model(candidate, "Economy saved. The audit has been recalculated.")
            st.rerun()
        except (ValueError, TypeError, KeyError) as error:
            st.error(f"Nothing was saved. {error}")
    st.caption("New rows need a unique ID and complete quantities. Item IDs must match the resources table. Use Undo in the sidebar to restore the previous model.")


def lab_view(model: dict, audit: dict) -> None:
    st.subheader("Test a balancing decision")
    cycle = cycle_select(audit, "lab_cycle")
    if not cycle:
        return
    show_verdict(cycle)
    recommendations = {r["id"]: r for r in cycle["recommendations"]}
    options = ["none", *recommendations]
    if st.session_state.get("patch_id") not in options:
        st.session_state.pop("patch_id", None)
    patch_id = st.selectbox("Proposed intervention", options, key="patch_id",
                            format_func=lambda key: "Current economy only" if key == "none" else recommendations[key]["title"])
    proposed = None
    if patch_id != "none":
        recommendation = recommendations[patch_id]
        proposed = apply_patch(model, recommendation["patch"])
        proposed_audit = analyze_json(json.dumps(proposed, sort_keys=True))
        after = next((c for c in proposed_audit["cycles"] if c["id"] == cycle["id"]), None)
        st.write(recommendation["description"])
        st.caption("Trade-off: " + recommendation["tradeoff"])
        left, right, total = st.columns(3)
        left.metric("Current gain / batch", f"{cycle['profit']:+g}")
        right.metric("Proposed gain / batch", f"{after['profit']:+g}" if after else "Route closed")
        total.metric("Attention findings", attention(proposed_audit), attention(proposed_audit) - attention(audit), delta_color="inverse")
        st.caption("The preview re-audits the whole entered economy. It does not change your working model.")
        if st.button("Apply proposed fix", type="primary", key="apply_patch"):
            commit_model(proposed, "Proposed fix applied and all routes re-audited.")
            st.rerun()
    elif not recommendations:
        st.info("This route has no automated correction. You can still simulate it or edit its transaction facts.")
    st.markdown("#### Simulate complete route batches")
    count_col, hours_col = st.columns(2)
    count = count_col.number_input("Requested batches", min_value=1, max_value=1000, value=10, step=1, key="sim_batches")
    hours = hours_col.number_input("Window (hours)", min_value=1, max_value=168, value=24, step=1, key="sim_hours")
    st.caption("One sequential account, with separately funded batches. Caps reset at synthetic midnight; global quotas start unused. No compounding or demand model.")
    if st.button("Run simulation", key="run_simulation"):
        series = [("Current", simulate(model, cycle["id"], count, hours))]
        if proposed:
            series.append(("Proposed", simulate(proposed, cycle["id"], count, hours)))
        chart = []
        for label, result in series:
            if result["verifiedWithinModel"]:
                st.success(f"{label}: {result['completedBatches']} complete batches · {result['totalProfit']:+g} {cycle['currencyName']} net gain")
                st.caption(result["reason"])
                chart += [{"Batch": point["batch"], "Net gain": point["cumulativeProfit"], "Economy": label} for point in result["timeline"]]
            else:
                st.warning(f"{label}: No estimate. {result['reason']}")
        if chart:
            st.line_chart(pd.DataFrame(chart), x="Batch", y="Net gain", color="Economy")
        with st.expander("Simulation assumptions"):
            for note in series[0][1]["notes"]:
                st.write("• " + note)


def knime_view(model: dict) -> None:
    st.subheader("KNIME decision workflow")
    st.write("Python derives the route facts. KNIME’s native Rule Engine applies the decision rules to those facts, writes its decisions, and compares them with the Python result.")
    st.code("Python facts → CSV Reader → Classification Rule Engine → Severity Rule Engine → CSV Writer", language=None)
    from loopguard.tables import audit_tables
    facts = audit_tables(model)["facts"]
    st.dataframe(facts, hide_index=True, width="stretch")
    serialized = json.dumps(model, sort_keys=True)
    st.download_button("Download KNIME exchange bundle", current_exchange_bundle(serialized), file_name="loopguard-knime-inputs.zip", mime="application/zip")
    st.caption("The bundle contains items, trades, route facts, rule traces and the exact project. Its SHA-256 fingerprint identifies the inputs.")
    st.download_button("Download current KNIME workflow", current_knime_archive(serialized), file_name="LoopGuard_Friendship_Fair.knwf", mime="application/zip", key="download_knime")
    st.caption("This workflow includes the current economy's facts. In KNIME: File → Import KNIME Workflow, select the .knwf, then execute all nodes. The final CSV Writer creates data/decisions.csv inside the imported workflow.")
    try:
        from knime.run_workflow import compare_decisions, knime_status, run_workflow
    except ImportError:
        st.info("Open the supplied KNIME workflow using the instructions in knime/README.md.")
        return
    st.markdown("#### Compare a manual KNIME run")
    decisions_file = st.file_uploader("KNIME decisions CSV", type=["csv"], key="knime_decisions")
    if st.button("Compare uploaded decisions", disabled=decisions_file is None, key="compare_knime"):
        st.session_state.pop("knime_result", None)
        try:
            if decisions_file.size > 1_000_000:
                raise ValueError("The decision file must be smaller than 1 MB.")
            decisions = pd.read_csv(io.BytesIO(decisions_file.getvalue()), dtype="string")
            comparison = compare_decisions(model, decisions)
            if comparison.empty:
                raise ValueError("No routes are available to compare.")
            st.session_state.knime_result = {
                "status": "matched" if comparison["matches"].all() else "mismatch",
                "matched": bool(comparison["matches"].all()), "fingerprint": fingerprint(model),
                "decisions": decisions, "comparison": comparison,
                "log": "Imported manual KNIME output. Input fingerprint and complete cycle coverage were checked; the desktop run itself was performed outside Streamlit.",
            }
        except (ValueError, KeyError, UnicodeDecodeError, pd.errors.ParserError) as error:
            st.error(f"Decision file rejected: {error}")
    st.markdown("#### Run KNIME automatically")
    status = knime_status()
    if status["batch_available"] is False:
        st.info(status["reason"])
    st.caption("Run locally uses an isolated KNIME workspace; it can take a minute on first launch.")
    if st.button("Run KNIME comparison", key="run_knime", type="primary", disabled=status["batch_available"] is False):
        st.session_state.pop("knime_result", None)
        try:
            with st.spinner("KNIME is evaluating the route facts…"):
                st.session_state.knime_result = run_workflow(model)
        except Exception as error:
            st.error(f"KNIME could not complete: {error}")
    result = st.session_state.get("knime_result")
    if result:

        if result.get("fingerprint") != fingerprint(model):
            st.warning("The KNIME result belongs to different inputs. Run the comparison again.")
        else:
            if result.get("status") == "empty":
                st.info("There are no return routes to classify. KNIME was not invoked.")
            elif result.get("matched"):
                st.success("KNIME and Python agree on every examined route.")
            else:
                st.error("KNIME and Python disagree. Inspect the comparison before using these decisions.")
            st.dataframe(result.get("comparison", result["decisions"]), hide_index=True, width="stretch")
            with st.expander("Execution details"):
                st.code(str(result.get("log", "")), language=None)


def exports_view(model: dict, audit: dict) -> None:
    st.subheader("Rule base and reproducible outputs")
    search = st.text_input("Find a rule", placeholder="LG24, intent, cooldown…", key="rule_search")
    rules = [rule for rule in RULES if search.lower() in json.dumps(rule).lower()]
    fired = {entry["ruleId"] for entry in audit["trace"]}
    st.dataframe(pd.DataFrame([{**r, "Triggered": r["id"] in fired} for r in rules]), hide_index=True, width="stretch")
    st.caption("Rules are project-authored policies. Explicit decision order resolves competing conclusions; no model training or API key is involved.")
    left, right = st.columns(2)
    left.download_button("Save project JSON", json.dumps(model, ensure_ascii=False, indent=2), "loopguard-project.json", "application/json", key="save_json")
    right.download_button("Save audit report", audit_markdown(model, audit), "loopguard-audit.md", "text/markdown", key="save_report")
    st.download_button("Save tables and reasoning", current_exchange_bundle(json.dumps(model, sort_keys=True)), "loopguard-tables.zip", "application/zip", key="save_bundle")
    with st.expander("Scope and assumptions"):
        st.write(audit["scope"]["description"])
        st.write("Known caps are declared facts, not verified server enforcement. An account-limit concern does not prove a real bypass. The rules and fictional game data require domain review before real use.")


if "model" not in st.session_state:
    st.session_state.model = deepcopy(SCENARIOS[0]["model"])
    st.session_state.history = []
    st.session_state.revision = 0

with st.sidebar:
    st.image(str(ROOT / "assets" / "hello-kitty.png"), width=65)
    st.header("Friendship Fair")
    st.caption("A fictional Sanrio economy")
    st.selectbox("Scenario preset", list(BY_SCENARIO), key="scenario_id", on_change=load_scenario,
                 format_func=lambda key: BY_SCENARIO[key]["name"])
    st.caption("Selecting a preset replaces the working economy. Imports and edits can differ from this preset.")
    st.caption(BY_SCENARIO[st.session_state.scenario_id]["description"])
    if st.button("Undo last change", disabled=not st.session_state.history, key="undo"):
        st.session_state.model = st.session_state.history.pop()
        st.session_state.revision += 1
        st.session_state.pop("knime_result", None)
        st.session_state.notice = "Previous economy restored."
        st.rerun()
    if st.button("Reset selected preset", key="reset_scenario"):
        load_scenario()
        st.rerun()
    uploaded = st.file_uploader("Import project JSON", type=["json"], key="project_upload")
    if st.button("Load imported project", disabled=uploaded is None, key="load_import"):
        try:
            commit_model(parse_project(uploaded.getvalue()), "Project imported and audited.")
            st.rerun()
        except ValueError as error:
            st.error(str(error))
    st.divider()
    st.caption("Edits stay in this Streamlit session. Export JSON to keep them after the session ends.")
    st.caption("Unofficial academic concept. Characters © SANRIO. All prices and rules are invented for this project.")

st.title("LoopGuard")
st.caption("Rule-based decision support · Python facts · KNIME decisions · Streamlit workspace")
if notice := st.session_state.pop("notice", None):
    st.success(notice)
model = st.session_state.model
audit = analyze_json(json.dumps(model, sort_keys=True))
st.session_state.audit = audit
if audit["scope"]["searchTruncated"]:
    st.warning("Partial search: the route or expansion limit was reached. Omitted routes are unassessed.")
workspace = st.radio("Workspace", ["Audit", "Edit economy", "Test a fix", "KNIME", "Rules & exports"], horizontal=True, key="workspace")
st.caption(f"{model['name']} · {len(model['transactions'])} trades · input fingerprint {fingerprint(model)[:12]}")
if workspace == "Audit":
    audit_view(model, audit)
elif workspace == "Edit economy":
    edit_view(model)
elif workspace == "Test a fix":
    lab_view(model, audit)
elif workspace == "KNIME":
    knime_view(model)
else:
    exports_view(model, audit)
