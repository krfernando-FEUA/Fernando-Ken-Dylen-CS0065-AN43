

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import tempfile
import zipfile

from .engine import analyze, validate

ROOT = Path(__file__).resolve().parents[1]
VERDICTS = {
    "critical": "Critical: repeatable profit",
    "high": "Needs attention",
    "review": "Needs evidence",
    "intended": "Intentional reward",
    "healthy": "No positive gain",
}


def scenarios() -> list[dict]:
    return json.loads((ROOT / "data" / "scenarios.json").read_text(encoding="utf-8"))


def fingerprint(model: dict) -> str:
    return sha256(json.dumps(model, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def parse_project(content: bytes) -> dict:
    if len(content) > 250_000:
        raise ValueError("Project must be smaller than 250 KB.")
    try:
        candidate = json.loads(content.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("Choose a valid UTF-8 JSON project.") from error
    result = validate(candidate)
    if not result["valid"]:
        raise ValueError(" ".join(result["errors"]))
    return candidate


def attention(audit: dict) -> int:
    return sum(audit["metrics"][s] for s in ("critical", "high", "review"))


def route_dot(model: dict, cycle: dict) -> str:

    items = {item["id"]: item for item in model["items"]}
    trades = {trade["id"]: trade for trade in model["transactions"]}
    quote = lambda text: json.dumps(str(text), ensure_ascii=False)
    lines = [
        "digraph route { rankdir=LR; graph [bgcolor=transparent, pad=0.2];",
        'node [shape=box, style="rounded,filled", fillcolor="#F7EAF2", color="#CEAEC5", fontname="Arial", fontsize=12];',
        'edge [color="#A94D7B", fontname="Arial", fontsize=10];',
    ]
    for item_id in dict.fromkeys(cycle["itemIds"]):
        lines.append(f"{quote(item_id)} [label={quote(items[item_id]['name'])}];")
    for step in cycle["steps"]:
        trade = trades[step["transactionId"]]
        label = f"{trade['character']} · {trade['name']}\n{step['inputAmount']:g} → {step['outputAmount']:g} · {step['executions']:g} execution(s)"
        lines.append(f"{quote(step['from'])} -> {quote(step['to'])} [label={quote(label)}];")
    return "\n".join(lines) + "\n}"


def audit_markdown(model: dict, audit: dict | None = None) -> str:
    audit = audit or analyze(model)
    safe = lambda value: str(value).replace("|", "\\|").replace("\n", " ")
    lines = [
        f"# LoopGuard audit — {safe(model['name'])}",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        f"Model SHA-256: `{fingerprint(model)}`",
        "Unofficial classroom Sanrio concept; all economy data is fictional.",
        f"\n{attention(audit)} attention findings; {audit['metrics']['intended']} intentional rewards; {audit['metrics']['cyclesAnalyzed']} examined routes.",
        "\n**PARTIAL SEARCH: resource limit reached.**" if audit["scope"]["searchTruncated"] else "\nSearch completed within the configured bounds.",
    ]
    for cycle in audit["cycles"]:
        lines += [f"\n## {safe(cycle['title'])}", f"**{VERDICTS[cycle['severity']]}** — {safe(cycle['summary'])}",
                  f"Exact batch: {cycle['startAmount']:g} → {cycle['endAmount']:g} {safe(cycle['currencyName'])}; net {cycle['profit']:+g}; ROI {cycle['roi']:+g}%."]
        for trace in cycle["trace"]:
            lines.append(f"- **{trace['ruleId']} — {safe(trace['label'])}:** {safe(trace['condition'])} → {safe(trace['conclusion'])}")
        for question in cycle["questions"]:
            lines.append(f"- Evidence needed: {safe(question)}")
        for recommendation in cycle["recommendations"]:
            lines.append(f"- Possible intervention: {safe(recommendation['description'])} Trade-off: {safe(recommendation['tradeoff'])}")
    lines += ["\n## Search scope", audit["scope"]["description"], "\n## Entered project", "```json", json.dumps(model, ensure_ascii=False, indent=2), "```"]
    return "\n\n".join(lines)


def editor_tables(model: dict):

    import pandas as pd
    items = pd.DataFrame(deepcopy(model["items"]))
    trades = pd.DataFrame(deepcopy(model["transactions"]))
    if trades.empty:
        trades = pd.DataFrame(columns=["id", "name", "character", "from", "to", "input", "output", "fee", "enabled", "kind", "cap", "capScope", "cooldown", "transferable", "intent"])
    trades["transferable"] = trades["transferable"].map({True: "yes", False: "no", None: "unknown"}).fillna("unknown")
    for key in ("input", "output", "fee", "cap", "cooldown"):
        trades[key] = trades[key].astype("float64")
    return items, trades


def model_from_editor(items, trades, *, name: str, scenario: str) -> dict:
    from .tables import model_from_tables
    normalized = trades.copy()
    values = {"yes": True, "no": False, "unknown": None}
    normalized["transferable"] = normalized["transferable"].map(lambda v: values[v] if v in values else v)
    return model_from_tables(items, normalized, name=name, scenario=scenario)


def knime_workflow_bytes(model: dict) -> bytes:

    from knime.export_tables import export_bundle
    with tempfile.TemporaryDirectory(prefix="loopguard-export-") as temporary:
        return export_bundle(model, temporary).read_bytes()


def exchange_bundle(model: dict) -> bytes:

    from .tables import audit_tables, model_to_tables
    items, trades = model_to_tables(model)
    tables = {"items": items, "transactions": trades, **audit_tables(model)}
    tables["facts"] = tables["facts"].assign(model_fingerprint=fingerprint(model))
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, frame in tables.items():
            filename = "cycle_facts" if name == "facts" else name
            archive.writestr(f"{filename}.csv", frame.to_csv(index=False))
        archive.writestr("project.json", json.dumps(model, indent=2, ensure_ascii=False))
        archive.writestr("audit.md", audit_markdown(model))
        archive.writestr("LoopGuard_Friendship_Fair.knwf", knime_workflow_bytes(model))
        archive.writestr("manifest.json", json.dumps({"model_sha256": fingerprint(model), "schema": "loopguard-v1", "source": "LoopGuard Python"}, indent=2))
    return output.getvalue()
