







from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
import json
import math
from pathlib import Path
import re
from typing import Any

MAX_DEPTH = 6
MAX_CYCLES = 3000
MAX_EXPANSIONS = 30000
RULES = json.loads(Path(__file__).with_name("rules.json").read_text(encoding="utf-8"))
_RULE_BY_ID = {rule["id"]: rule for rule in RULES}
_ALLOWED_CHANGES = {
    "name", "input", "output", "fee", "enabled", "character", "kind",
    "cooldown", "cap", "capScope", "transferable", "intent", "from", "to",
}
_MISSING = object()


def _round(value: float | int) -> float:

    return math.floor((value + 2.220446049250313e-16) * 100_000_000 + 0.5) / 100_000_000


def _fmt(value: float | int) -> str:

    return str(int(value)) if value == int(value) else format(value, ".15g")


def _decimal(value: Any, minimum: float, maximum: float) -> bool:

    return (
        type(value) in (int, float)
        and minimum <= value <= maximum
        and math.isfinite(value)
        and abs(value * 100 - round(value * 100)) < 1e-6
    )


def _integer(value: Any) -> bool:
    return type(value) is int or (type(value) is float and math.isfinite(value) and value == int(value))


def _units(value: float | int) -> int:
    return int(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) * 100)


def validate(model: Any) -> dict:

    errors: list[str] = []
    if not isinstance(model, dict):
        return {"valid": False, "errors": ["The economy must be a JSON object."]}
    if model.get("schema") != "loopguard-v1":
        errors.append("Unsupported schema; expected loopguard-v1.")

    def text(value: Any, limit: int = 100) -> bool:
        return isinstance(value, str) and bool(value.strip()) and len(value) <= limit

    def identifier(value: Any) -> bool:
        return isinstance(value, str) and re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,47}", value) is not None

    if not text(model.get("name")):
        errors.append("Economy name must contain 1–100 characters.")
    if not text(model.get("scenario")):
        errors.append("Scenario must contain 1–100 characters.")
    items, transactions = model.get("items"), model.get("transactions")
    if not isinstance(items, list) or not 2 <= len(items) <= 30:
        errors.append("Provide 2–30 items.")
    if not isinstance(transactions, list) or len(transactions) > 80:
        errors.append("Provide at most 80 transactions.")
    if not isinstance(items, list) or not isinstance(transactions, list):
        return {"valid": False, "errors": errors}
    ids: set[str] = set()
    trade_ids: set[str] = set()
    for index, item in enumerate(items, 1):
        prefix = f"Item {index}"
        if not isinstance(item, dict):
            errors.append(f"{prefix} must be an object.")
            continue
        item_id = item.get("id")
        if not identifier(item_id) or item_id in ids:
            errors.append(f"{prefix} has an invalid or duplicate ID.")
        if isinstance(item_id, str):
            ids.add(item_id)
        if not text(item.get("name")):
            errors.append(f"{prefix} needs a name.")
        if item.get("kind") not in ("currency", "material", "crafted"):
            errors.append(f"{prefix} has an invalid kind.")
        if "icon" in item and (not isinstance(item["icon"], str) or len(item["icon"]) > 40):
            errors.append(f"{prefix} icon must be short text.")
    if not any(isinstance(item, dict) and item.get("kind") == "currency" for item in items):
        errors.append("At least one currency item is required.")
    for index, transaction in enumerate(transactions, 1):
        prefix = f"Transaction {index}"
        if not isinstance(transaction, dict):
            errors.append(f"{prefix} must be an object.")
            continue
        t = transaction
        transaction_id = t.get("id")
        if not identifier(transaction_id) or transaction_id in trade_ids:
            errors.append(f"{prefix} has an invalid or duplicate ID.")
        if isinstance(transaction_id, str):
            trade_ids.add(transaction_id)
        if not text(t.get("name")) or not text(t.get("character")):
            errors.append(f"{prefix} needs a name and character.")
        if not (isinstance(t.get("from"), str) and isinstance(t.get("to"), str)
                and t["from"] in ids and t["to"] in ids and t["from"] != t["to"]):
            errors.append(f"{prefix} must connect two different known items.")
        if not _decimal(t.get("input"), 0.01, 1_000_000) or not _decimal(t.get("output"), 0.01, 1_000_000):
            errors.append(f"{prefix} input/output must be 0.01–1,000,000 with at most two decimals.")
        if not _decimal(t.get("fee"), 0, 1_000_000):
            errors.append(f"{prefix} fee must be 0–1,000,000 with at most two decimals.")
        if type(t.get("enabled")) is not bool:
            errors.append(f"{prefix} enabled must be true or false.")
        if t.get("kind") not in ("buy", "craft", "sell", "exchange", "reward"):
            errors.append(f"{prefix} has an invalid kind.")
        cooldown = t.get("cooldown", _MISSING)
        if not (cooldown is None or _decimal(cooldown, 0, 43200)):
            errors.append(f"{prefix} cooldown must be null or 0–43,200 minutes with at most two decimals.")
        cap = t.get("cap", _MISSING)
        if not (cap is None or (_integer(cap) and 0 <= cap <= 1_000_000)):
            errors.append(f"{prefix} cap must be null or an integer from 0 to 1,000,000.")
        if t.get("capScope") not in ("account", "global"):
            errors.append(f"{prefix} capScope must be account or global.")
        transferable = t.get("transferable", _MISSING)
        if not (transferable is None or type(transferable) is bool):
            errors.append(f"{prefix} transferable must be true, false, or null.")
        if t.get("intent") not in ("unintended", "intended", "unknown"):
            errors.append(f"{prefix} has an invalid intent.")
    return {"valid": not errors, "errors": errors}


def _require_valid(model: Any) -> None:
    validation = validate(model)
    if not validation["valid"]:
        raise ValueError(" ".join(validation["errors"]))


def apply_patch(model: dict, patch: dict) -> dict:

    _require_valid(model)
    if not (isinstance(patch, dict) and isinstance(patch.get("transactionId"), str)
            and isinstance(patch.get("changes"), dict)):
        raise ValueError("A patch needs a transactionId and changes object.")
    if any(key not in _ALLOWED_CHANGES for key in patch["changes"]):
        raise ValueError("Patch contains an unsupported transaction property.")
    updated = deepcopy(model)
    target = next((t for t in updated["transactions"] if t["id"] == patch["transactionId"]), None)
    if target is None:
        raise ValueError("Patch transaction was not found.")
    target.update(deepcopy(patch["changes"]))
    _require_valid(updated)
    return updated


def _exact_batch(path: list[dict]) -> tuple[list[int], int, int]:

    ratio = Fraction(1)
    ratios = [ratio]
    multiple = 1
    for previous, current in zip(path, path[1:]):
        ratio *= Fraction(_units(previous["output"]) - _units(previous["fee"]), _units(current["input"]))
        ratios.append(ratio)
        multiple = math.lcm(multiple, ratio.denominator)
    counts = [multiple * ratio.numerator // ratio.denominator for ratio in ratios]
    start_units = counts[0] * _units(path[0]["input"])
    end_units = counts[-1] * (_units(path[-1]["output"]) - _units(path[-1]["fee"]))
    return counts, start_units, end_units


def _find_cycles(model: dict) -> tuple[list[list[dict]], bool, int]:
    outgoing: dict[str, list[dict]] = {item["id"]: [] for item in model["items"]}
    for t in model["transactions"]:
        if t["enabled"] and t["output"] > t["fee"]:
            outgoing[t["from"]].append(t)
    paths: list[list[dict]] = []
    signatures: set[str] = set()
    expansions = 0
    truncated = False

    def visit(root: str, node: str, path: list[dict], visited: set[str]) -> None:
        nonlocal expansions, truncated
        for edge in outgoing[node]:
            if expansions >= MAX_EXPANSIONS or len(paths) >= MAX_CYCLES:
                truncated = True
                return
            expansions += 1
            next_path = [*path, edge]
            if edge["to"] == root:
                ids = [t["id"] for t in next_path]
                signature = min("|".join(ids[i:] + ids[:i]) for i in range(len(ids)))
                if signature not in signatures:
                    signatures.add(signature)
                    paths.append(next_path)
            elif len(next_path) < MAX_DEPTH and edge["to"] not in visited:
                visit(root, edge["to"], next_path, visited | {edge["to"]})
            if truncated:
                return

    for currency in (item for item in model["items"] if item["kind"] == "currency"):
        visit(currency["id"], currency["id"], [], {currency["id"]})
        if truncated:
            break
    return paths, truncated, expansions


def _fire(trace: list[dict], rule_id: str, condition: str, conclusion: str) -> None:
    trace.append({"ruleId": rule_id, "label": _RULE_BY_ID[rule_id]["label"],
                  "condition": condition, "conclusion": conclusion})


def _evaluate(path: list[dict], model: dict) -> dict:
    trace: list[dict] = []

    def fire(rule_id: str, condition: str, conclusion: str) -> None:
        _fire(trace, rule_id, condition, conclusion)

    counts, start_units, end_units = _exact_batch(path)
    start_amount, end_amount = start_units / 100, end_units / 100
    profit = _round((end_units - start_units) / 100)
    positive, equal = end_units > start_units, end_units == start_units
    roi = _round(profit / start_amount * 100)
    limited_caps = [t for t in path if t["cap"] is not None and t["cap"] > 0]
    unknown_caps = [t for t in path if t["cap"] is None]
    cooldowns = [t for t in path if t["cooldown"] is not None and t["cooldown"] > 0]
    unknown_cooldowns = [t for t in path if t["cooldown"] is None]
    account_caps = [t for t in limited_caps if t["capScope"] == "account"]
    global_caps = [t for t in limited_caps if t["capScope"] == "global"]
    transferable_caps = [t for t in account_caps if t["transferable"] is True]
    unknown_transfers = [t for t in account_caps if t["transferable"] is None]
    bound_outputs = [t for t in account_caps if t["transferable"] is False]
    all_intended = all(t["intent"] == "intended" for t in path)
    has_unintended = any(t["intent"] == "unintended" for t in path)
    has_unknown_intent = any(t["intent"] == "unknown" for t in path)
    mixed_intent = has_unintended and any(t["intent"] == "intended" for t in path)
    unknown_limits = bool(unknown_caps or unknown_cooldowns)
    bounded = bool(limited_caps or cooldowns)
    oversized = start_amount > 1_000_000_000
    names = lambda rows: ", ".join(t["name"] for t in rows)
    terminal = path[-1]
    currency = next(item for item in model["items"] if item["id"] == path[0]["from"])
    pivot = next((t for t in path if t["kind"] == "craft"), path[0])
    product = next(item for item in model["items"] if item["id"] == pivot["to"])
    fire("LG03", f"{len(path)} transactions return to {currency['name']}.", "A closed conversion route was found.")
    fire("LG04", f"Minimum starting batch: {_fmt(_round(start_amount))} {currency['name']}.", "Every step executes a whole number of times; no leftover assets are credited.")
    if any(t["fee"] > 0 for t in path):
        fire("LG05", names([t for t in path if t["fee"] > 0]), "Output fees are deducted once per execution.")
    fire("LG06" if positive else "LG07" if equal else "LG08",
         f"{_fmt(_round(start_amount))} → {_fmt(_round(end_amount))} {currency['name']}.",
         f"Net gain {_fmt(profit)}; return {_fmt(roi)}%." if positive else
         "There is no positive return." if equal else f"Net loss {_fmt(_round(-profit))}.")
    if not unknown_caps and not limited_caps:
        fire("LG09", "All caps are explicitly zero.", "No execution cap is encoded.")
    if limited_caps:
        fire("LG10", names(limited_caps), "At least one finite daily execution cap applies.")
    if unknown_caps:
        fire("LG11", names(unknown_caps), "Execution-cap information is incomplete.")
    if not unknown_cooldowns and not cooldowns:
        fire("LG12", "All cooldowns are explicitly zero.", "No time delay is encoded.")
    if cooldowns:
        fire("LG13", names(cooldowns), "A cooldown limits steady full-day throughput.")
    if unknown_cooldowns:
        fire("LG14", names(unknown_cooldowns), "Cooldown information is incomplete.")
    if account_caps:
        fire("LG15", names(account_caps), "These caps are per account, not a shared economy-wide ceiling.")
    if global_caps:
        fire("LG16", names(global_caps), "A shared global allocation is explicitly encoded.")
    if transferable_caps:
        fire("LG17", names(transferable_caps), "Outputs could be pooled across accounts; identity, ownership and transfer enforcement remain untested.")
    if bound_outputs:
        fire("LG18", names(bound_outputs), "These capped outputs are marked nontransferable; broader account behavior is outside the model.")
    if unknown_transfers:
        fire("LG19", names(unknown_transfers), "Verify whether capped outputs can move between accounts.")
    if all_intended:
        fire("LG20", "All route transactions are marked intended.", "The route has an explicit intended-reward interpretation.")
    if has_unintended:
        fire("LG21", names([t for t in path if t["intent"] == "unintended"]), "At least one transaction identifies this return as unintended.")
    if has_unknown_intent:
        fire("LG22", names([t for t in path if t["intent"] == "unknown"]), "Some design intent is unrecorded.")
    if mixed_intent:
        fire("LG23", "The route combines intended and unintended labels.", "A route-level design decision is needed.")

    severity = "healthy"
    classification = "break-even" if equal else "losing-route"
    summary = ("Returns its entry cost after fees. No positive return was found on this route." if equal else
               "Returns less than its entry cost after fees. No positive return was found on this route.")
    if positive:
        if oversized:
            severity, classification = "review", "oversized-batch"
            summary = "The mathematics is profitable, but the minimum whole-execution batch is unusually large. Verify feasibility and inventory limits."
            fire("LG34", f"Minimum entry {_fmt(_round(start_amount))} exceeds one billion.", summary)
        elif unknown_limits or unknown_transfers:
            severity, classification = "review", "unverified-repeatability"
            summary = "A positive return is verified. Missing limit or transfer facts prevent a complete repeatability assessment."
            fire("LG29", "Required repetition or transfer facts are unknown.", summary)
        elif has_unknown_intent or mixed_intent:
            severity, classification = "review", "unverified-intent"
            summary = f"This route earns currency{' under known limits' if bounded else ' with no encoded limits'}, but its design intent needs clarification."
            fire("LG29", "Design intent is unknown or inconsistent.", summary)
        elif not bounded and all_intended:
            severity, classification = "high", "unbounded-intended-reward"
            summary = "The return is marked intentional, but no cap or cooldown bounds its repetition within the entered model."
            fire("LG25", "Positive return + intended labels + no caps or cooldowns.", summary)
        elif not bounded:
            severity, classification = "critical", "repeatable-profit"
            summary = "The route earns currency and can repeat without an encoded cap or cooldown. This is a confirmed profit loop within the entered model."
            fire("LG24", "Positive return + unintended label + explicitly absent limits.", summary)
        elif all_intended:
            severity, classification = "intended", "intended-reward"
            summary = "This is an explicitly intended reward with a known throughput limit. Preserve it unless its budget is too high."
            fire("LG28", "Positive return + intended labels + known finite limit.", summary)
        elif transferable_caps and not global_caps:
            severity, classification = "high", "account-limit-risk"
            summary = "The offer is limited per account, but its output is transferable. Investigate cross-account aggregation; an unlimited bypass is not established."
            fire("LG26", "Positive return + transferable account-capped output + no global cap.", summary)
        else:
            severity, classification = "high", "bounded-arbitrage"
            summary = "The route yields unintended profit under known limits. Limits reduce throughput but leave the pricing mismatch."
            fire("LG27", "Positive return + unintended label + finite limits.", summary)

    questions: list[str] = []
    if positive:
        questions.extend(f"What is the daily execution cap for {t['name']}? Enter 0 only if it is verified unlimited." for t in unknown_caps)
        questions.extend(f"Does {t['name']} have a cooldown, and how many minutes is it?" for t in unknown_cooldowns)
        questions.extend(f"Can the output of {t['name']} be transferred between accounts?" for t in unknown_transfers)
        if has_unknown_intent or mixed_intent:
            questions.append("Is the positive return of this entire route intended by the economy designer?")
        if classification == "account-limit-risk":
            questions.append("Can one person aggregate these outputs across accounts, and does a server-side shared or identity-level restriction stop it?")
        if oversized:
            questions.append("Can players hold the minimum batch, and are inventory or wallet limits enforced?")
    steps = [{"transactionId": t["id"], "from": t["from"], "to": t["to"], "executions": count,
              "inputAmount": count * _units(t["input"]) / 100,
              "outputAmount": count * (_units(t["output"]) - _units(t["fee"])) / 100,
              "feeAmount": count * _units(t["fee"]) / 100} for t, count in zip(path, counts)]
    account_bounds, global_bounds = [], []
    for t, count in zip(path, counts):
        if t["cap"] is not None and t["cap"] > 0:
            bound = int(t["cap"]) // count
            account_bounds.append(bound)
            if t["capScope"] == "global":
                global_bounds.append(bound)
        if t["cooldown"] is not None and t["cooldown"] > 0:

            account_bounds.append(math.ceil(Fraction(144000, _units(t["cooldown"]))) // count)
    account_daily_limit = min(account_bounds) if account_bounds else None
    global_daily_limit = min(global_bounds) if global_bounds else None
    daily_limit = account_daily_limit if global_daily_limit is None else global_daily_limit
    facts = [
        {"label": "Net return", "value": f"{_fmt(roi)}% after fees", "known": True},
        {"label": "Execution caps", "value": "Some unknown" if unknown_caps else "Finite cap exists" if limited_caps else "Explicitly unlimited", "known": not unknown_caps},
        {"label": "Cooldowns", "value": "Some unknown" if unknown_cooldowns else "Known cooldown applies" if cooldowns else "Explicitly absent", "known": not unknown_cooldowns},
        {"label": "Design intent", "value": "Intended" if all_intended else "Conflicting" if mixed_intent else "Partly unknown" if has_unknown_intent else "Unintended", "known": not has_unknown_intent and not mixed_intent},
        {"label": "Full batches / day", "value": ("Not established" if unknown_limits else "No finite bound encoded") if daily_limit is None else f"At most {daily_limit} {'per account' if global_daily_limit is None else 'globally'}", "known": daily_limit is not None or not unknown_limits},
    ]
    recommendations = []
    if positive and severity != "intended" and not oversized:
        max_net_units = start_units // counts[-1]
        new_output_units = max_net_units + _units(terminal["fee"])
        new_fee_units = _units(terminal["output"]) - max_net_units
        if 0 < new_output_units <= 100_000_000:
            recommendations.append({"id": "align-buyback", "title": "Align the buyback", "description": f"Set {terminal['name']} output to {_fmt(new_output_units / 100)} {currency['name']} per execution. This route becomes break-even or loss-making.", "patch": {"transactionId": terminal["id"], "changes": {"output": new_output_units / 100}}, "tradeoff": "Keeps the entry price and crafting recipe accessible; reduces resale or reward proceeds."})
            fire("LG31", f"{terminal['name']} is the terminal payout.", "A lower payout removes this route’s positive return; preview rechecks all enumerated routes.")
        if 0 <= new_fee_units <= 100_000_000:
            recommendations.append({"id": "add-output-fee", "title": "Add a settlement fee", "description": f"Set the {terminal['name']} output fee to {_fmt(new_fee_units / 100)} {currency['name']} per execution.", "patch": {"transactionId": terminal["id"], "changes": {"fee": new_fee_units / 100}}, "tradeoff": "Preserves the advertised gross payout but lowers what players actually receive."})
            fire("LG30", "The terminal fee can absorb the excess return.", "This route’s net return becomes nonpositive.")
        if not global_caps:
            recommendations.append({"id": "bound-payout", "title": "Set a shared payout budget", "description": f"Give {terminal['name']} a global cap of 3 executions per day. The pricing gain remains, but payout volume is bounded.", "patch": {"transactionId": terminal["id"], "changes": {"cap": 3, "capScope": "global"}}, "tradeoff": "A shared budget can be exhausted by early players. Use only if that distribution is intentional."})
            fire("LG32", "No positive global cap is encoded.", "A shared execution budget is an alternative throughput control, not a pricing fix.")
    return {
        "id": "cycle-" + "--".join(t["id"].replace("--", "%2D%2D") for t in path),
        "title": f"{product['name']} {'return path' if positive else 'conversion path'}",
        "currencyId": currency["id"], "currencyName": currency["name"],
        "severity": severity, "character": pivot["character"], "transactionIds": [t["id"] for t in path],
        "itemIds": [path[0]["from"], *(t["to"] for t in path)],
        "startAmount": _round(start_amount), "endAmount": _round(end_amount), "profit": profit, "roi": roi,
        "classification": classification, "summary": summary, "facts": facts, "trace": trace,
        "questions": questions, "recommendations": recommendations, "steps": steps,
        "dailyLimit": daily_limit, "accountDailyLimit": account_daily_limit, "globalDailyLimit": global_daily_limit,
        "limitScope": "global" if global_caps else "account" if account_caps else "cooldown" if cooldowns else "none",
    }


def analyze(model: dict) -> dict:

    _require_valid(model)
    paths, truncated, expansions = _find_cycles(model)
    trace: list[dict] = []
    enabled_count = sum(t["enabled"] for t in model["transactions"])
    _fire(trace, "LG01", f"{enabled_count} transactions are enabled.", "Only enabled, positive-net-output transactions enter the graph.")
    consumed = [t for t in model["transactions"] if t["enabled"] and t["output"] <= t["fee"]]
    if consumed:
        _fire(trace, "LG02", ", ".join(t["name"] for t in consumed), "These edges have no usable net output and were excluded.")
    order = {"critical": 0, "high": 1, "review": 2, "intended": 3, "healthy": 4}
    cycles = [_evaluate(path, model) for path in paths]
    cycles.sort(key=lambda cycle: (order[cycle["severity"]], -cycle["roi"], cycle["id"].lower(), cycle["id"]))
    findings = [cycle for cycle in cycles if cycle["profit"] > 0]
    for cycle in cycles:
        trace.extend({**entry, "cycleId": cycle["id"]} for entry in cycle["trace"])
    if not findings:
        _fire(trace, "LG33", "No enumerated currency route has positive return.", "No modeled positive-return route was found within the stated search scope.")
    if truncated:
        _fire(trace, "LG35", "The route or search-expansion budget was reached.", "This assessment is incomplete; simplify the graph or inspect omitted paths separately.")
    count = lambda severity: sum(c["severity"] == severity for c in cycles)
    return {
        "cycles": cycles, "findings": findings, "trace": trace,
        "metrics": {"enabledTransactions": enabled_count, "cyclesAnalyzed": len(cycles),
                    "critical": count("critical"), "high": count("high"), "review": count("review"),
                    "healthy": count("healthy") + count("intended"), "intended": count("intended"),
                    "profitableCycles": len(findings), "rulesFired": len({t["ruleId"] for t in trace}),
                    "ruleApplications": len(trace), "searchTruncated": truncated},
        "scope": {"maxDepth": MAX_DEPTH, "maxCycles": MAX_CYCLES, "maxExpansions": MAX_EXPANSIONS,
                  "expansions": expansions, "searchTruncated": truncated,
                  "description": "Simple currency-rooted cycles of up to six transactions; one input and one output per transaction. All conclusions depend on the supplied facts. Inventory, demand, identity enforcement, multiple-input recipes, and longer or compound cycles are outside this model. Daily bounds use whole batches from fresh inputs in one daily quota window; inventories may accumulate across days. Cooldowns apply per account, allowing an initially eligible execution in a 24-hour window. Account and global bounds are reported separately."},
    }


def simulate(model: dict, cycle_id: str, requested_batches: int, hours: int) -> dict:






    if not _integer(requested_batches) or not 1 <= requested_batches <= 1000:
        raise ValueError("Simulation batches must be an integer from 1 to 1,000.")
    if not _integer(hours) or not 1 <= hours <= 168:
        raise ValueError("Simulation hours must be an integer from 1 to 168.")
    requested_batches, hours = int(requested_batches), int(hours)
    analysis = analyze(model)
    cycle = next((c for c in analysis["cycles"] if c["id"] == cycle_id), None)
    notes = [
        "One account with separately funded batches; returned currency is not reinvested. Only complete batches are executed.",
        "Daily quotas reset at 24-hour boundaries from time zero. Global quotas are assumed unused by other players.",
        "Transactions take no time beyond their entered cooldowns. Inventory supply and player demand are assumed available.",
    ]
    result = {
        "cycleId": cycle_id, "currencyId": cycle["currencyId"] if cycle else None,
        "currencyName": cycle["currencyName"] if cycle else None,
        "requestedBatches": requested_batches, "hours": hours, "completedBatches": 0,
        "totalProfit": 0, "totalReturned": 0,
        "seedBudget": _round(cycle["startAmount"] * requested_batches) if cycle else 0, "seedUsed": 0,
        "elapsedMinutes": 0, "status": "no-route", "verifiedWithinModel": False,
        "reason": "The selected route is no longer available under this model.", "notes": notes,
        "timeline": [{"batch": 0, "timeMinutes": 0, "hours": 0, "cumulativeProfit": 0, "totalProfit": 0}],
    }
    if cycle is None:
        return result
    by_id = {t["id"]: t for t in model["transactions"]}
    path = [by_id[transaction_id] for transaction_id in cycle["transactionIds"]]
    missing = [t for t in path if t["cap"] is None or t["cooldown"] is None]
    if missing:
        result["status"] = "unknown"
        result["reason"] = f"Simulation requires verified caps and cooldowns for: {', '.join(t['name'] for t in missing)}. No profit estimate was made."
        return result
    if cycle["startAmount"] > 1_000_000_000 or any(step["executions"] > 9_007_199_254_740_991 for step in cycle["steps"]):
        result["status"] = "unsupported"
        result["reason"] = "The exact execution batch is unusually large. Verify wallet and inventory feasibility before simulating."
        return result

    day_length, end_time = 144000, hours * 6000
    now = 0
    state = {t["id"]: {"day": 0, "dailyCount": 0, "nextAllowed": 0} for t in path}
    blocked_by = None

    def schedule_step(transaction: dict, needed: int, at: int, record: dict) -> tuple[bool, int]:
        cooldown = _units(transaction["cooldown"])
        remaining, time = needed, max(at, record["nextAllowed"])
        while remaining > 0:
            if time >= end_time:
                return False, time
            day = time // day_length
            day_end = (day + 1) * day_length
            if record["day"] != day:
                record["day"], record["dailyCount"] = day, 0
            quota = remaining if transaction["cap"] == 0 else int(transaction["cap"]) - record["dailyCount"]
            if quota <= 0:
                time = max(day_end, record["nextAllowed"])
                continue
            window_end = min(day_end, end_time)
            time_slots = remaining if cooldown == 0 else (window_end - 1 - time) // cooldown + 1
            count = min(remaining, quota, time_slots)
            if count <= 0:
                time = max(window_end, record["nextAllowed"])
                continue
            last_execution = time + (count - 1) * cooldown
            record["dailyCount"] += count
            record["nextAllowed"] = last_execution + cooldown
            remaining -= count
            if remaining > 0:
                quota_boundary = day_end if transaction["cap"] > 0 and record["dailyCount"] >= transaction["cap"] else 0
                time = max(record["nextAllowed"], quota_boundary)
            else:
                time = last_execution
        return True, time

    for batch in range(1, requested_batches + 1):
        candidate_state = deepcopy(state)
        candidate_time, complete = now, True
        for transaction, step in zip(path, cycle["steps"]):
            complete, candidate_time = schedule_step(transaction, step["executions"], candidate_time, candidate_state[transaction["id"]])
            if not complete:
                blocked_by = transaction
                break
        if not complete:
            break
        state, now = candidate_state, candidate_time
        result["completedBatches"] = batch
        result["totalProfit"] = _round(cycle["profit"] * batch)
        result["totalReturned"] = _round(cycle["endAmount"] * batch)
        result["seedUsed"] = _round(cycle["startAmount"] * batch)
        result["timeline"].append({"batch": batch, "timeMinutes": now / 100, "hours": now / 6000,
                                   "cumulativeProfit": result["totalProfit"], "totalProfit": result["totalProfit"]})
    result["elapsedMinutes"] = now / 100
    result["verifiedWithinModel"] = True
    result["status"] = "complete" if result["completedBatches"] == requested_batches else "limited"
    result["blockingTransactionId"] = blocked_by["id"] if blocked_by else None
    result["reason"] = (
        f"All {requested_batches} requested batches finish inside the {hours}-hour window."
        if result["status"] == "complete" else
        f"Only {result['completedBatches']} complete batches fit before hour {hours}; {blocked_by['name']} reaches a daily quota or cooldown boundary. No partial final batch is executed."
    )
    notes.append(f"The {_fmt(_round(result['seedBudget']))} starting-currency budget reserves a separate seed amount for every requested batch.")
    if cycle["questions"]:
        notes.append("Any unresolved intent or transfer questions remain; this simulation establishes only the entered single-account timing and returns.")
    return result
