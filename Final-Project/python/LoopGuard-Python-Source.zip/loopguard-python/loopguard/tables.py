




from __future__ import annotations

import math
import numbers
import hashlib
import json
from typing import Any

import pandas as pd

from .engine import RULES, analyze, validate

ITEM_COLUMNS = ("id", "name", "kind", "icon")
TRANSACTION_COLUMNS = (
    "id", "name", "from", "to", "input", "output", "fee", "enabled",
    "character", "kind", "cooldown", "cap", "capScope", "transferable", "intent",
)


def model_fingerprint(model: dict) -> str:

    def normalize(value):
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, list):
            return [normalize(item) for item in value]
        if isinstance(value, float) and math.isfinite(value) and value.is_integer():
            return int(value)
        return value
    canonical = json.dumps(normalize(model), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _missing(value: Any) -> bool:
    if value is None or value is pd.NA:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, numbers.Real):
        return math.isnan(float(value))
    return False


def _text(value: Any, location: str, optional: bool = False) -> str:
    if _missing(value):
        if optional:
            return ""
        raise ValueError(f"{location}: a text value is required.")
    if not isinstance(value, str):
        raise ValueError(f"{location}: expected text, got {type(value).__name__}.")
    return value.strip()


def _number(value: Any, location: str, nullable: bool = False) -> float | int | None:
    if _missing(value):
        if nullable:
            return None
        raise ValueError(f"{location}: a number is required.")
    if isinstance(value, (bool,)) or type(value).__name__ == "bool_":
        raise ValueError(f"{location}: a boolean is not a number.")
    if not isinstance(value, (str, numbers.Real)):
        raise ValueError(f"{location}: expected a finite number.")
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{location}: expected a finite number.") from exc
    if not math.isfinite(result):
        raise ValueError(f"{location}: expected a finite number.")
    return int(result) if result.is_integer() else result


def _boolean(value: Any, location: str, nullable: bool = False) -> bool | None:
    if _missing(value):
        if nullable:
            return None
        raise ValueError(f"{location}: true or false is required.")
    if isinstance(value, bool) or type(value).__name__ == "bool_":
        return bool(value)
    if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
        return value.strip().lower() == "true"
    raise ValueError(f"{location}: use true or false (blank only when unknown is allowed).")


def _columns(frame: pd.DataFrame, required: tuple[str, ...], label: str) -> None:
    if not isinstance(frame, pd.DataFrame):
        raise ValueError(f"{label} must be a pandas DataFrame.")
    if frame.columns.duplicated().any():
        raise ValueError(f"{label} contains duplicate column names.")
    missing = set(required) - set(frame.columns)
    if missing:
        raise ValueError(f"{label} is missing columns: {', '.join(sorted(missing))}.")


def model_from_tables(items: pd.DataFrame, transactions: pd.DataFrame, *,
                      name: str = "Friendship Fair", scenario: str = "knime-import") -> dict:

    _columns(items, ITEM_COLUMNS[:-1], "Items")
    _columns(transactions, TRANSACTION_COLUMNS, "Transactions")
    model = {"schema": "loopguard-v1", "name": name, "scenario": scenario,
             "items": [], "transactions": []}
    for index, row in enumerate(items.to_dict("records"), 1):
        item = {key: _text(row.get(key), f"Item {index}.{key}", key == "icon")
                for key in ITEM_COLUMNS}
        model["items"].append(item)
    for index, row in enumerate(transactions.to_dict("records"), 1):
        transaction = {}
        for key in TRANSACTION_COLUMNS:
            location = f"Transaction {index}.{key}"
            if key in {"input", "output", "fee", "cap", "cooldown"}:
                transaction[key] = _number(row[key], location, key in {"cap", "cooldown"})
            elif key in {"enabled", "transferable"}:
                transaction[key] = _boolean(row[key], location, key == "transferable")
            else:
                transaction[key] = _text(row[key], location)
        model["transactions"].append(transaction)
    result = validate(model)
    if not result["valid"]:
        raise ValueError("Invalid economy: " + "; ".join(result["errors"]))
    return model


def _frame(rows: list[dict], schema: dict[str, str]) -> pd.DataFrame:

    return pd.DataFrame({key: pd.Series([row.get(key) for row in rows], dtype=dtype)
                         for key, dtype in schema.items()})


def model_to_tables(model: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    result = validate(model)
    if not result["valid"]:
        raise ValueError("Invalid economy: " + "; ".join(result["errors"]))
    items = _frame(model["items"], {key: "string" for key in ITEM_COLUMNS})
    schema = {key: "string" for key in TRANSACTION_COLUMNS}
    schema.update({key: "Float64" for key in ("input", "output", "fee", "cooldown")})
    schema.update({"cap": "Int64", "enabled": "boolean", "transferable": "boolean"})
    return items, _frame(model["transactions"], schema)


CYCLE_SCHEMA = {
    "cycle_id": "string", "title": "string", "character": "string",
    "severity": "string", "classification": "string", "currency": "string",
    "start_amount": "Float64", "end_amount": "Float64", "profit": "Float64",
    "roi_percent": "Float64", "daily_limit": "Float64", "summary": "string",
    "transaction_ids": "string",
}
FACT_SCHEMA = {
    "cycle_id": "string", "title": "string", "profit": "Float64",
    "start_amount": "Float64", "unknown_limits": "Int64", "unknown_transfers": "Int64",
    "unknown_intent": "Int64", "mixed_intent": "Int64", "bounded": "Int64",
    "all_intended": "Int64", "transferable_account_cap": "Int64", "global_cap": "Int64",
}
TRACE_SCHEMA = {"cycle_id": "string", "step": "Int64", "rule_id": "string",
                "label": "string", "condition": "string", "conclusion": "string"}


def audit_tables(model: dict) -> dict[str, pd.DataFrame]:

    result = analyze(model)
    by_id = {transaction["id"]: transaction for transaction in model["transactions"]}
    item_names = {item["id"]: item["name"] for item in model["items"]}
    cycles, facts, traces = [], [], []
    for cycle in result["cycles"]:
        path = [by_id[key] for key in cycle["transactionIds"]]
        cycles.append({
            "cycle_id": cycle["id"], "title": cycle["title"], "character": cycle["character"],
            "severity": cycle["severity"], "classification": cycle["classification"],
            "currency": item_names[path[0]["from"]], "start_amount": cycle["startAmount"],
            "end_amount": cycle["endAmount"], "profit": cycle["profit"],
            "roi_percent": cycle["roi"], "daily_limit": cycle.get("dailyLimit"),
            "summary": cycle["summary"], "transaction_ids": " > ".join(cycle["transactionIds"]),
        })
        account_caps = [t for t in path if t["cap"] is not None and t["cap"] > 0 and t["capScope"] == "account"]
        facts.append({
            "cycle_id": cycle["id"], "title": cycle["title"], "profit": cycle["profit"],
            "start_amount": cycle["startAmount"],
            "unknown_limits": int(any(t["cap"] is None or t["cooldown"] is None for t in path)),
            "unknown_transfers": int(any(t["transferable"] is None for t in account_caps)),
            "unknown_intent": int(any(t["intent"] == "unknown" for t in path)),
            "mixed_intent": int(any(t["intent"] == "intended" for t in path) and any(t["intent"] == "unintended" for t in path)),
            "bounded": int(any((t["cap"] or 0) > 0 or (t["cooldown"] or 0) > 0 for t in path)),
            "all_intended": int(all(t["intent"] == "intended" for t in path)),
            "transferable_account_cap": int(any(t["transferable"] is True for t in account_caps)),
            "global_cap": int(any((t["cap"] or 0) > 0 and t["capScope"] == "global" for t in path)),
        })
        for step, trace in enumerate(cycle["trace"], 1):
            traces.append({"cycle_id": cycle["id"], "step": step,
                           "rule_id": trace["ruleId"], "label": trace["label"],
                           "condition": trace["condition"], "conclusion": trace["conclusion"]})
    cycles_frame = _frame(cycles, CYCLE_SCHEMA)
    for step, trace in enumerate((entry for entry in result["trace"] if not entry.get("cycleId")), 1):
        traces.append({"cycle_id": "audit", "step": step, "rule_id": trace["ruleId"],
                       "label": trace["label"], "condition": trace["condition"], "conclusion": trace["conclusion"]})
    return {
        "cycles": cycles_frame,
        "findings": cycles_frame.loc[cycles_frame["profit"] > 0].reset_index(drop=True),
        "trace": _frame(traces, TRACE_SCHEMA),
        "facts": _frame(facts, FACT_SCHEMA),
        "rules": _frame(RULES, {"id": "string", "label": "string", "description": "string",
                                 "priority": "Int64", "category": "string"}),
    }
