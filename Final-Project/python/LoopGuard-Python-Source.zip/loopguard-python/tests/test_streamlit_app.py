






from __future__ import annotations

from copy import deepcopy
import io
import json
from pathlib import Path
import sys
import zipfile

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest
from streamlit.runtime.memory_media_file_storage import MemoryMediaFileStorage

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from loopguard import analyze
from loopguard.tables import model_fingerprint

SCENARIOS = json.loads((ROOT / "data" / "scenarios.json").read_text(encoding="utf-8"))
SCENARIO_BY_ID = {scenario["id"]: scenario for scenario in SCENARIOS}


def assert_clean(app: AppTest) -> None:
    assert not app.exception, "\n".join(exception.message for exception in app.exception)


def rendered_text(app: AppTest) -> str:
    kinds = ("title", "header", "subheader", "markdown", "caption", "info", "warning", "error", "success")
    return "\n".join(str(element.value) for kind in kinds for element in getattr(app, kind))


def transaction(model: dict, transaction_id: str) -> dict:
    return next(item for item in model["transactions"] if item["id"] == transaction_id)


@pytest.fixture
def app() -> AppTest:
    instance = AppTest.from_file(str(ROOT / "app.py"), default_timeout=15).run()
    assert_clean(instance)
    return instance


def navigate(app: AppTest, workspace: str) -> AppTest:
    app.radio(key="workspace").set_value(workspace).run()
    assert_clean(app)
    return app


def set_scenario(app: AppTest, scenario_id: str) -> AppTest:
    app.selectbox(key="scenario_id").set_value(scenario_id).run()
    assert_clean(app)
    return app


def test_initial_audit_exposes_actual_economy_and_explanation(app: AppTest) -> None:
    assert app.session_state["model"] == SCENARIO_BY_ID["friendship-fair"]["model"]
    assert len(app.session_state["model"]["transactions"]) == 15
    metrics = analyze(app.session_state["model"])["metrics"]
    assert (metrics["critical"], metrics["high"], metrics["intended"]) == (1, 1, 1)
    assert "Friendship" in rendered_text(app)
    assert app.selectbox(key="audit_cycle").value
    assert app.dataframe, "The audit should expose its evidence tables."


@pytest.mark.parametrize("workspace", ["Audit", "Edit economy", "Test a fix", "KNIME", "Rules & exports"])
def test_every_workspace_renders_without_losing_model(app: AppTest, workspace: str) -> None:
    original = deepcopy(app.session_state["model"])
    navigate(app, workspace)
    assert app.session_state["model"] == original
    assert rendered_text(app).strip()


@pytest.mark.parametrize("scenario_id", list(SCENARIO_BY_ID))
def test_scenario_widget_loads_the_selected_case_atomically(app: AppTest, scenario_id: str) -> None:
    set_scenario(app, scenario_id)
    assert app.session_state["model"] == SCENARIO_BY_ID[scenario_id]["model"]
    for workspace in ("Audit", "Test a fix"):
        navigate(app, workspace)
        assert app.session_state["model"] == SCENARIO_BY_ID[scenario_id]["model"]


def test_sessions_do_not_share_economy_edits(app: AppTest) -> None:
    set_scenario(app, "festival-rush")
    second = AppTest.from_file(str(ROOT / "app.py"), default_timeout=15).run()
    assert_clean(second)
    assert transaction(app.session_state["model"], "gift-buyback")["output"] == 30
    assert transaction(second.session_state["model"], "gift-buyback")["output"] == 24


def editor_delta(app: AppTest, *, rows: dict | None = None, deleted: list | None = None,
                 added: list | None = None, items: bool = False) -> None:
    prefix = "items" if items else "trades"
    key = f"{prefix}_editor_{app.session_state['revision']}"
    app.session_state[key] = {"edited_rows": rows or {}, "added_rows": added or [], "deleted_rows": deleted or []}


def save_editor(app: AppTest) -> None:
    next(button for button in app.button if button.label == "Save & audit").click().run()
    assert_clean(app)


def test_valid_editor_changes_reaudit_and_undo_restores_original(app: AppTest) -> None:
    original = deepcopy(app.session_state["model"])
    navigate(app, "Edit economy")
    editor_delta(app, rows={2: {"output": 20.0}})
    save_editor(app)
    assert transaction(app.session_state["model"], "gift-buyback")["output"] == 20
    assert app.session_state["audit"]["metrics"]["critical"] == 0
    assert len(app.session_state["history"]) == 1
    app.button(key="undo").click().run()
    assert_clean(app)
    assert app.session_state["model"] == original
    assert app.session_state["audit"]["metrics"]["critical"] == 1


@pytest.mark.parametrize("rows,deleted_items", [
    ({2: {"output": -1.0}}, []),
    ({2: {"from": "missing-item"}}, []),
    ({2: {"id": "ribbon-shop"}}, []),
    ({2: {"output": 20.0}}, [0]),
])
def test_invalid_table_submission_changes_neither_model_nor_history(app: AppTest, rows: dict, deleted_items: list) -> None:
    original = deepcopy(app.session_state["model"])
    navigate(app, "Edit economy")
    editor_delta(app, rows=rows)
    if deleted_items:
        editor_delta(app, deleted=deleted_items, items=True)
    save_editor(app)
    assert app.session_state["model"] == original
    assert app.session_state["history"] == []
    assert "Nothing was saved" in rendered_text(app)


def test_editor_keeps_unknown_limits_distinct_from_unlimited(app: AppTest) -> None:
    set_scenario(app, "missing-telemetry")
    navigate(app, "Edit economy")
    editor_delta(app, rows={2: {"name": "Gift buyback under investigation"}})
    save_editor(app)
    gift = transaction(app.session_state["model"], "gift-buyback")
    assert gift["cap"] is None and gift["cooldown"] is None
    assert gift["name"] == "Gift buyback under investigation"
    assert transaction(app.session_state["model"], "ribbon-shop")["cap"] == 0


def test_dynamic_editor_adds_a_trade_and_deletes_it_with_updated_routes(app: AppTest) -> None:
    navigate(app, "Edit economy")
    added = {**transaction(app.session_state["model"], "gift-buyback"),
             "id": "festival-buyback", "name": "Festival gift buyback", "output": 26.0, "transferable": "yes"}
    editor_delta(app, added=[added])
    save_editor(app)
    assert len(app.session_state["model"]["transactions"]) == 16
    new_route = next(c for c in app.session_state["audit"]["cycles"] if "festival-buyback" in c["transactionIds"])
    assert new_route["profit"] == 6
    editor_delta(app, deleted=[15])
    save_editor(app)
    assert len(app.session_state["model"]["transactions"]) == 15
    assert not any("festival-buyback" in c["transactionIds"] for c in app.session_state["audit"]["cycles"])


def select_cycle(app: AppTest, transaction_id: str) -> dict:
    cycle = next(c for c in app.session_state["audit"]["cycles"] if transaction_id in c["transactionIds"])
    app.selectbox(key="lab_cycle").set_value(cycle["id"]).run()
    assert_clean(app)
    return cycle


def test_patch_preview_is_nonmutating_apply_reaudits_and_undo_restores(app: AppTest) -> None:
    original = deepcopy(app.session_state["model"])
    navigate(app, "Test a fix")
    cycle = select_cycle(app, "gift-workshop")
    recommendation = next(r for r in cycle["recommendations"] if r["patch"]["changes"].get("output") == 20)
    app.selectbox(key="patch_id").set_value(recommendation["id"]).run()
    assert_clean(app)
    assert app.session_state["model"] == original
    assert app.session_state["history"] == []
    assert any(metric.label == "Proposed gain / batch" and metric.value == "+0" for metric in app.metric)
    app.button(key="apply_patch").click().run()
    assert_clean(app)
    assert transaction(app.session_state["model"], "gift-buyback")["output"] == 20
    assert app.session_state["audit"]["metrics"]["critical"] == 0
    app.button(key="undo").click().run()
    assert_clean(app)
    assert app.session_state["model"] == original


@pytest.mark.parametrize("transaction_id,batches,profit", [
    ("gift-workshop", 10, 40),
    ("charm-workshop", 2, 8),
    ("latte-recipe", 3, 12),
])
def test_simulation_uses_each_routes_actual_daily_constraints(app: AppTest, transaction_id: str, batches: int, profit: int) -> None:
    navigate(app, "Test a fix")
    select_cycle(app, transaction_id)
    app.number_input(key="sim_batches").set_value(10)
    app.number_input(key="sim_hours").set_value(24)
    app.button(key="run_simulation").click().run()
    assert_clean(app)
    assert f"{batches} complete batches · +{profit} Friendship Coins net gain" in rendered_text(app)


def test_unknown_telemetry_simulation_shows_no_estimate(app: AppTest) -> None:
    set_scenario(app, "missing-telemetry")
    navigate(app, "Test a fix")
    select_cycle(app, "gift-workshop")
    app.button(key="run_simulation").click().run()
    assert_clean(app)
    text = rendered_text(app)
    assert "No estimate" in text
    assert "No profit estimate was made" in text
    assert "complete batches ·" not in text


def upload_project(app: AppTest, content: bytes) -> None:
    app.file_uploader(key="project_upload").set_value(("project.json", content, "application/json")).run()
    assert_clean(app)
    app.button(key="load_import").click().run()
    assert_clean(app)


def test_imported_project_is_used_in_current_audit_and_can_be_undone(app: AppTest) -> None:
    original = deepcopy(app.session_state["model"])
    imported = deepcopy(SCENARIO_BY_ID["balanced-market"]["model"])
    imported["name"] = "Kuromi's test market"
    upload_project(app, json.dumps(imported).encode())
    assert app.session_state["model"] == imported
    assert app.session_state["audit"]["metrics"]["critical"] == 0
    assert "Kuromi's test market" in rendered_text(app)
    app.button(key="undo").click().run()
    assert_clean(app)
    assert app.session_state["model"] == original


@pytest.mark.parametrize("content", [b"not json", b"{}", b"\xff", b" " * 250_001],
                         ids=["malformed-json", "invalid-schema", "non-utf8", "oversize"])
def test_invalid_import_preserves_current_audit_and_history(app: AppTest, content: bytes) -> None:
    original = deepcopy(app.session_state["model"])
    audit = deepcopy(app.session_state["audit"])
    upload_project(app, content)
    assert app.session_state["model"] == original
    assert app.session_state["audit"] == audit
    assert app.session_state["history"] == []
    assert app.error


def test_empty_economy_has_actionable_views_instead_of_stale_route(app: AppTest) -> None:
    empty = deepcopy(app.session_state["model"])
    empty["transactions"] = []
    upload_project(app, json.dumps(empty).encode())
    for workspace in ("Audit", "Test a fix", "Edit economy", "KNIME", "Rules & exports"):
        navigate(app, workspace)
        assert app.session_state["audit"]["metrics"]["cyclesAnalyzed"] == 0
    navigate(app, "Audit")
    assert not [element for element in app.selectbox if element.key == "audit_cycle"]
    assert "No currency return routes" in rendered_text(app)


def test_rule_search_and_downloads_contain_current_reproducible_inputs(app: AppTest, monkeypatch: pytest.MonkeyPatch) -> None:
    captured = {}
    original_load = MemoryMediaFileStorage.load_and_get_id

    def capture(storage, path_or_data, mimetype, kind, filename=None):
        file_id = original_load(storage, path_or_data, mimetype, kind, filename)
        if filename:
            captured[filename] = storage._files_by_id[file_id].content
        return file_id

    monkeypatch.setattr(MemoryMediaFileStorage, "load_and_get_id", capture)
    set_scenario(app, "festival-rush")
    navigate(app, "Rules & exports")
    app.text_input(key="rule_search").set_value("LG24").run()
    assert_clean(app)
    assert len(app.dataframe[0].value) == 1
    assert app.dataframe[0].value.iloc[0]["id"] == "LG24"
    assert json.loads(captured["loopguard-project.json"]) == app.session_state["model"]
    assert b"Search scope" in captured["loopguard-audit.md"]
    with zipfile.ZipFile(io.BytesIO(captured["loopguard-tables.zip"])) as archive:
        assert {"project.json", "manifest.json", "cycle_facts.csv", "trace.csv", "transactions.csv"} <= set(archive.namelist())
        assert json.loads(archive.read("project.json")) == app.session_state["model"]
    app.download_button(key="save_json").click().run()
    assert_clean(app)
    assert app.session_state["model"] == SCENARIO_BY_ID["festival-rush"]["model"]


def manual_decisions(model: dict) -> pd.DataFrame:

    return pd.DataFrame([{
        "cycle_id": cycle["id"],
        "knime_classification": cycle["classification"],
        "knime_severity": cycle["severity"],
        "model_fingerprint": model_fingerprint(model),
    } for cycle in analyze(model)["cycles"]])


def upload_decisions(app: AppTest, content: bytes) -> None:
    app.file_uploader(key="knime_decisions").set_value(("decisions.csv", content, "text/csv")).run()
    assert_clean(app)
    app.button(key="compare_knime").click().run()
    assert_clean(app)


def test_manual_knime_upload_accepts_complete_matching_current_decisions(app: AppTest) -> None:
    original = deepcopy(app.session_state["model"])
    navigate(app, "KNIME")
    upload_decisions(app, manual_decisions(original).to_csv(index=False).encode())
    result = app.session_state["knime_result"]
    assert result["status"] == "matched" and result["matched"] is True
    assert result["fingerprint"] == model_fingerprint(original)
    assert len(result["comparison"]) == 6
    assert result["comparison"]["matches"].all()
    assert "KNIME and Python agree on every examined route" in rendered_text(app)
    assert app.session_state["model"] == original
    assert app.session_state["history"] == []


@pytest.mark.parametrize("invalid_case", ["stale-model", "missing-fields", "missing-route", "duplicate-route"])
def test_rejected_knime_upload_clears_prior_accepted_comparison(app: AppTest, invalid_case: str) -> None:
    navigate(app, "KNIME")
    model = deepcopy(app.session_state["model"])
    good = manual_decisions(model)
    upload_decisions(app, good.to_csv(index=False).encode())
    assert app.session_state["knime_result"]["matched"]
    if invalid_case == "stale-model":
        invalid = manual_decisions(SCENARIO_BY_ID["festival-rush"]["model"])
    elif invalid_case == "missing-fields":
        invalid = good.drop(columns="knime_severity")
    elif invalid_case == "missing-route":
        invalid = good.iloc[:-1]
    else:
        invalid = pd.concat([good, good.iloc[[0]]], ignore_index=True)
    upload_decisions(app, invalid.to_csv(index=False).encode())
    assert app.session_state.get("knime_result") is None
    assert "Decision file rejected" in rendered_text(app)
    assert "KNIME and Python agree on every examined route" not in rendered_text(app)
    assert app.session_state["model"] == model


def test_downloaded_knime_workflow_uses_current_model_after_scenario_change(app: AppTest, monkeypatch: pytest.MonkeyPatch) -> None:
    captured = {}
    original_load = MemoryMediaFileStorage.load_and_get_id

    def capture(storage, path_or_data, mimetype, kind, filename=None):
        file_id = original_load(storage, path_or_data, mimetype, kind, filename)
        if filename:
            captured[filename] = storage._files_by_id[file_id].content
        return file_id

    monkeypatch.setattr(MemoryMediaFileStorage, "load_and_get_id", capture)
    navigate(app, "KNIME")
    fingerprints = []
    for scenario_id in ("friendship-fair", "festival-rush"):
        if scenario_id != "friendship-fair":
            set_scenario(app, scenario_id)
        expected = SCENARIO_BY_ID[scenario_id]["model"]
        content = captured["LoopGuard_Friendship_Fair.knwf"]
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            def read_member(suffix: str) -> bytes:
                return archive.read(next(name for name in archive.namelist() if name.endswith(suffix)))

            assert json.loads(read_member("/data/model.json")) == expected
            manifest = json.loads(read_member("/data/manifest.json"))
            facts = pd.read_csv(io.BytesIO(read_member("/data/cycle_facts.csv")))
            expected_fingerprint = model_fingerprint(expected)
            assert manifest["fingerprint"] == expected_fingerprint
            assert manifest["scenario"] == scenario_id
            assert set(facts["model_fingerprint"]) == {expected_fingerprint}
            gift = facts.loc[facts["cycle_id"].str.contains("gift-workshop")].iloc[0]
            assert gift["profit"] == (4 if scenario_id == "friendship-fair" else 10)
            fingerprints.append(expected_fingerprint)
    assert fingerprints[0] != fingerprints[1]
    app.download_button(key="download_knime").click().run()
    assert_clean(app)
    assert app.session_state["model"] == SCENARIO_BY_ID["festival-rush"]["model"]
