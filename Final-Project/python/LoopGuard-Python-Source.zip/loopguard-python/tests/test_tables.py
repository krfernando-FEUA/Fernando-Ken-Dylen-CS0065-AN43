import copy
import json
from pathlib import Path

import pandas as pd
import pytest

from loopguard.engine import analyze
from loopguard.tables import audit_tables, model_from_tables, model_to_tables


@pytest.fixture
def model():
    scenarios = json.loads((Path(__file__).resolve().parents[1] / "data/scenarios.json").read_text(encoding="utf-8"))
    return copy.deepcopy(scenarios[0]["model"])


def test_round_trip_preserves_unknown_and_zero(model):
    model["transactions"][0].update(cap=None, cooldown=0, transferable=None)
    items, transactions = model_to_tables(model)
    rebuilt = model_from_tables(items, transactions, name=model["name"], scenario=model["scenario"])
    assert rebuilt == model
    assert rebuilt["transactions"][0]["cap"] is None
    assert rebuilt["transactions"][0]["cooldown"] == 0


@pytest.mark.parametrize("field,value", [("enabled", "yes"), ("enabled", 1),
                                        ("transferable", "maybe"), ("input", True),
                                        ("input", "nan"), ("fee", float("inf")),
                                        ("output", "1,000"), ("cap", 1.5)])
def test_malformed_values_are_rejected(model, field, value):
    items, transactions = model_to_tables(model)
    transactions = transactions.astype(object)
    transactions.loc[0, field] = value
    with pytest.raises(ValueError):
        model_from_tables(items, transactions)


def test_blank_unknown_cells_and_explicit_boolean_strings(model):
    items, transactions = model_to_tables(model)
    transactions = transactions.astype(object)
    transactions.loc[0, "cooldown"] = " "
    transactions.loc[0, "transferable"] = ""
    transactions.loc[0, "enabled"] = " FALSE "
    rebuilt = model_from_tables(items, transactions)
    first = rebuilt["transactions"][0]
    assert first["cooldown"] is None and first["transferable"] is None
    assert first["enabled"] is False


def test_missing_columns_and_duplicate_columns_rejected(model):
    items, transactions = model_to_tables(model)
    with pytest.raises(ValueError, match="missing columns"):
        model_from_tables(items, transactions.drop(columns="cap"))
    with pytest.raises(ValueError, match="duplicate column"):
        model_from_tables(pd.concat([items, items[["id"]]], axis=1), transactions)


def test_outputs_agree_with_engine_and_include_audit_trace(model):
    frames = audit_tables(model)
    result = analyze(model)
    assert len(frames["cycles"]) == len(result["cycles"]) == 6
    assert len(frames["findings"]) == 3
    assert set(frames["cycles"]["severity"]) == {"critical", "high", "intended", "healthy"}
    assert set(frames["facts"]["cycle_id"]) == set(frames["cycles"]["cycle_id"])
    assert "LG01" in set(frames["trace"]["rule_id"])
    assert len(frames["trace"]) == len(result["trace"])
    assert len(frames["rules"]) == 35


def test_empty_frames_keep_typed_columns(model):
    for trade in model["transactions"]:
        trade["enabled"] = False
    frames = audit_tables(model)
    for key in ("cycles", "findings", "facts"):
        assert frames[key].empty
        assert str(frames[key]["profit"].dtype) == "Float64"
        assert str(frames[key]["cycle_id"].dtype) == "string"
    assert set(frames["trace"]["rule_id"]) == {"LG01", "LG33"}


def test_csv_round_trip_uses_blank_only_for_unknown(model, tmp_path):
    model["transactions"][0].update(cap=None, cooldown=None, transferable=None)
    items, trades = model_to_tables(model)
    items.to_csv(tmp_path / "items.csv", index=False)
    trades.to_csv(tmp_path / "trades.csv", index=False)
    restored = model_from_tables(pd.read_csv(tmp_path / "items.csv", dtype=str, keep_default_na=False),
                                 pd.read_csv(tmp_path / "trades.csv", dtype=str, keep_default_na=False),
                                 name=model["name"], scenario=model["scenario"])
    assert restored == model
