

from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
import random
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from loopguard import RULES, analyze, apply_patch, simulate, validate

SCENARIOS = json.loads((ROOT / "data" / "scenarios.json").read_text(encoding="utf-8-sig"))


def base():
    return deepcopy(SCENARIOS[0]["model"])


def scenario(name):
    return deepcopy(next(s["model"] for s in SCENARIOS if s["id"] == name))


def patch(model, transaction_id, **changes):
    return apply_patch(model, {"transactionId": transaction_id, "changes": changes})


def route(result, transaction_id):
    return next(c for c in result["cycles"] if transaction_id in c["transactionIds"])


def gift(model):
    return route(analyze(model), "gift-buyback")


def small(inputs=(10, 1), outputs=(1, 12)):
    model = base()
    model["items"] = model["items"][:2]
    model["transactions"] = [
        {**model["transactions"][0], "id": "a", "input": inputs[0], "output": outputs[0]},
        {**model["transactions"][3], "id": "b", "input": inputs[1], "output": outputs[1]},
    ]
    return model


class ExpertEngineTests(unittest.TestCase):
    def test_01_shipped_scenarios_and_documented_baseline(self):
        for example in SCENARIOS:
            self.assertEqual(validate(example["model"]), {"valid": True, "errors": []})
        metrics = analyze(base())["metrics"]
        for key, expected in {"enabledTransactions": 15, "cyclesAnalyzed": 6, "critical": 1,
                              "high": 1, "intended": 1, "profitableCycles": 3}.items():
            self.assertEqual(metrics[key], expected)

    def test_02_gift_exact_whole_batches(self):
        finding = gift(base())
        for key, expected in {"startAmount": 20, "endAmount": 24, "profit": 4, "roi": 20}.items():
            self.assertEqual(finding[key], expected)
        self.assertEqual([s["executions"] for s in finding["steps"]], [2, 1, 1])
        self.assertEqual([(s["inputAmount"], s["outputAmount"]) for s in finding["steps"]], [(20, 2), (2, 1), (1, 24)])
        self.assertEqual(finding["classification"], "repeatable-profit")

    def test_03_account_risk_is_a_hypothesis(self):
        finding = route(analyze(base()), "charm-buyback")
        self.assertEqual(finding["severity"], "high")
        self.assertEqual(finding["classification"], "account-limit-risk")
        self.assertEqual(finding["dailyLimit"], 2)
        self.assertIsNone(finding["globalDailyLimit"])
        self.assertIn("unlimited bypass is not established", finding["summary"])
        self.assertTrue(any("identity-level" in q for q in finding["questions"]))

    def test_04_intentional_cafe_reward_preserved(self):
        finding = route(analyze(base()), "cafe-orders")
        self.assertEqual(finding["severity"], "intended")
        self.assertEqual(finding["globalDailyLimit"], 3)
        self.assertEqual(finding["dailyLimit"], 3)
        self.assertEqual(finding["roi"], 40)
        self.assertEqual(finding["recommendations"], [])

    def test_05_balanced_scenario_retains_only_intended_profit(self):
        result = analyze(scenario("balanced-market"))
        self.assertEqual(sum(result["metrics"][k] for k in ("critical", "high", "review")), 0)
        self.assertEqual(len(result["findings"]), 1)
        self.assertEqual(result["findings"][0]["severity"], "intended")

    def test_06_unknown_limits_never_mean_unlimited(self):
        finding = gift(patch(base(), "gift-buyback", cap=None, cooldown=None))
        self.assertEqual(finding["severity"], "review")
        self.assertEqual(finding["classification"], "unverified-repeatability")
        self.assertEqual(len(finding["questions"]), 2)
        fired = {entry["ruleId"] for entry in finding["trace"]}
        self.assertNotIn("LG24", fired)
        self.assertTrue({"LG11", "LG14"}.issubset(fired))

    def test_07_unknown_and_bound_transfer_policy(self):
        unknown = route(analyze(patch(base(), "wish-kiosk", transferable=None)), "charm-buyback")
        self.assertEqual(unknown["severity"], "review")
        self.assertTrue(any("transferred" in q for q in unknown["questions"]))
        bound = route(analyze(patch(base(), "wish-kiosk", transferable=False)), "charm-buyback")
        self.assertEqual(bound["classification"], "bounded-arbitrage")
        self.assertIn("LG18", [t["ruleId"] for t in bound["trace"]])

    def test_08_unknown_or_conflicting_intent(self):
        self.assertEqual(gift(patch(base(), "gift-buyback", intent="unknown"))["classification"], "unverified-intent")
        mixed = gift(patch(base(), "gift-buyback", intent="intended"))
        self.assertEqual(mixed["classification"], "unverified-intent")
        self.assertIn("LG23", [t["ruleId"] for t in mixed["trace"]])

    def test_09_unbounded_intended_reward_is_reviewable(self):
        finding = route(analyze(scenario("festival-rush")), "cafe-orders")
        self.assertEqual(finding["classification"], "unbounded-intended-reward")
        self.assertEqual(finding["severity"], "high")

    def test_10_pricing_corrections_remove_profit_without_mutation(self):
        original = base()
        saved = deepcopy(original)
        for finding in analyze(original)["findings"]:
            if finding["severity"] == "intended":
                continue
            for recommendation in finding["recommendations"]:
                if recommendation["id"] == "bound-payout":
                    continue
                result = analyze(apply_patch(original, recommendation["patch"]))
                changed = next((c for c in result["cycles"] if c["id"] == finding["id"]), None)
                self.assertTrue(changed is None or changed["profit"] <= 0)
                self.assertTrue(any(c["severity"] == "intended" for c in result["findings"]))
        self.assertEqual(original, saved)

    def test_11_global_quota_bounds_volume_not_pricing(self):
        model = base()
        recommendation = next(r for r in gift(model)["recommendations"] if r["id"] == "bound-payout")
        finding = gift(apply_patch(model, recommendation["patch"]))
        self.assertEqual((finding["profit"], finding["severity"], finding["globalDailyLimit"]), (4, "high", 3))

    def test_12_intermediate_fees_per_execution(self):
        model = small((10, 1), (2, 8))
        model["transactions"][0]["fee"] = 0.5
        model["transactions"][1]["fee"] = 1
        finding = analyze(model)["cycles"][0]
        self.assertEqual((finding["startAmount"], finding["endAmount"], finding["profit"]), (20, 21, 1))
        self.assertEqual([s["executions"] for s in finding["steps"]], [2, 3])
        self.assertEqual([s["feeAmount"] for s in finding["steps"]], [1, 3])

    def test_13_decimal_recipe_exact_lots(self):
        finding = analyze(small((0.25, 0.3), (0.2, 0.5)))["cycles"][0]
        self.assertEqual((finding["startAmount"], finding["endAmount"], finding["profit"]), (0.75, 1, 0.25))
        self.assertEqual([s["executions"] for s in finding["steps"]], [3, 2])

    def test_14_corrections_cannot_leave_subcent_profit(self):
        model = small((1, 3), (7, 1))
        finding = analyze(model)["findings"][0]
        self.assertEqual((finding["startAmount"], finding["endAmount"]), (3, 7))
        for recommendation in finding["recommendations"]:
            if recommendation["id"] != "bound-payout":
                self.assertLessEqual(analyze(apply_patch(model, recommendation["patch"]))["cycles"][0]["profit"], 0)

    def test_15_nonpositive_net_edges_excluded(self):
        for fee in (12, 13):
            model = patch(small(), "b", fee=fee)
            result = analyze(model)
            self.assertEqual(result["cycles"], [])
            self.assertTrue({"LG02", "LG33"}.issubset({t["ruleId"] for t in result["trace"]}))

    def test_16_disabled_edges_and_immutable_analysis(self):
        model = patch(base(), "gift-buyback", enabled=False)
        saved = deepcopy(model)
        result = analyze(model)
        self.assertTrue(all("gift-buyback" not in c["transactionIds"] for c in result["cycles"]))
        self.assertEqual(result["metrics"]["enabledTransactions"], 14)
        self.assertEqual(model, saved)

    def test_17_account_and_global_bounds_stay_distinct(self):
        model = patch(base(), "gift-workshop", cap=2, capScope="account")
        model = patch(model, "gift-buyback", cap=100, capScope="global")
        finding = gift(model)
        self.assertEqual((finding["accountDailyLimit"], finding["globalDailyLimit"], finding["dailyLimit"]), (2, 100, 100))
        self.assertIn("100 globally", next(f["value"] for f in finding["facts"] if f["label"] == "Full batches / day"))

    def test_18_long_cooldown_allows_initial_execution(self):
        finding = analyze(patch(small(), "b", cooldown=43200))["cycles"][0]
        self.assertEqual(finding["accountDailyLimit"], 1)
        self.assertEqual(finding["classification"], "bounded-arbitrage")

    def test_19_subbatch_quota_does_not_claim_impossibility(self):
        model = small((10, 1), (0.5, 24))
        model["transactions"][0]["cap"] = 1
        finding = analyze(model)["cycles"][0]
        self.assertEqual((finding["startAmount"], finding["accountDailyLimit"], finding["profit"]), (20, 0, 4))
        self.assertIn("inventories may accumulate", analyze(model)["scope"]["description"])

    def test_20_rotation_of_currency_cycle_deduplicated(self):
        model = small()
        model["items"][1]["kind"] = "currency"
        self.assertEqual(len(analyze(model)["cycles"]), 1)

    def test_21_parallel_trades_are_distinct_routes(self):
        model = small()
        model["transactions"].append({**model["transactions"][1], "id": "alternative", "output": 9})
        result = analyze(model)
        self.assertEqual(len(result["cycles"]), 2)
        self.assertEqual(len(result["findings"]), 1)
        self.assertEqual(len({c["id"] for c in result["cycles"]}), 2)

    def test_22_depth_bound_is_explicit(self):
        model = small()
        model["items"] = [{"id": f"i{i}", "name": f"Item {i}", "kind": "currency" if i == 0 else "material"} for i in range(7)]
        model["transactions"] = [{**model["transactions"][0], "id": f"t{i}", "from": f"i{i}", "to": f"i{(i+1)%7}", "input": 1, "output": 2 if i == 6 else 1} for i in range(7)]
        result = analyze(model)
        self.assertEqual(result["cycles"], [])
        self.assertEqual(result["scope"]["maxDepth"], 6)
        self.assertIn("longer or compound cycles are outside", result["scope"]["description"])

    def test_23_dense_graph_terminates_and_discloses_truncation(self):
        model = small()
        model["items"] = [{"id": f"i{i}", "name": f"Item {i}", "kind": "currency" if i == 0 else "material"} for i in range(10)]
        template = model["transactions"][0]
        model["transactions"] = [{**template, "id": f"t{i}_{j}", "from": f"i{i}", "to": f"i{j}", "input": 1, "output": 1} for i in range(10) for j in range(10) if i != j][:80]
        result = analyze(model)
        self.assertTrue(result["scope"]["searchTruncated"])
        self.assertLessEqual(result["scope"]["expansions"], result["scope"]["maxExpansions"])
        self.assertLessEqual(len(result["cycles"]), result["scope"]["maxCycles"])
        self.assertIn("LG35", [t["ruleId"] for t in result["trace"]])

    def test_24_oversized_batch_requires_review(self):
        model = base()
        model["transactions"] = model["transactions"][:3]
        for transaction, (input_, output) in zip(model["transactions"], ((999983, 999979), (999961, 999959), (999953, 1000000))):
            transaction.update(input=input_, output=output)
        finding = analyze(model)["findings"][0]
        self.assertGreater(finding["startAmount"], 1e9)
        self.assertEqual(finding["classification"], "oversized-batch")
        self.assertEqual(finding["recommendations"], [])
        self.assertEqual(simulate(model, finding["id"], 1, 24)["status"], "unsupported")

    def test_25_invalid_imports_rejected(self):
        changes = [
            ("input", "10"), ("input", 0), ("input", 0.001), ("output", float("inf")),
            ("fee", -1), ("enabled", "true"), ("cap", 0.5), ("cooldown", -1),
            ("transferable", "unknown"), ("intent", "safe"), ("to", "missing"),
        ]
        invalid_models = []
        for key, value in changes:
            model = base()
            model["transactions"][0][key] = value
            invalid_models.append(model)
        for field in ("cap", "cooldown", "transferable"):
            model = base()
            del model["transactions"][0][field]
            invalid_models.append(model)
        for where in ("items", "transactions"):
            model = base(); model[where][0] = None; invalid_models.append(model)
            model = base(); model[where][0]["id"] = model[where][1]["id"]; invalid_models.append(model)
            model = base(); model[where] = None; invalid_models.append(model)
        model = base(); model["schema"] = "other"; invalid_models.append(model)
        for model in invalid_models:
            with self.subTest(model=model):
                self.assertFalse(validate(model)["valid"])
                with self.assertRaises(ValueError):
                    analyze(model)

    def test_26_patch_validation_is_atomic(self):
        model, saved = base(), base()
        for p in ({"transactionId": "missing", "changes": {"output": 20}},
                  {"transactionId": "gift-buyback", "changes": {"id": "changed"}},
                  {"transactionId": "gift-buyback", "changes": {"output": -1}},
                  {"transactionId": "gift-buyback", "changes": None}):
            with self.assertRaises(ValueError):
                apply_patch(model, p)
        self.assertEqual(model, saved)

    def test_27_rules_are_unique_and_explanations_bear_evidence(self):
        rule_ids = {r["id"] for r in RULES}
        self.assertEqual(len(rule_ids), 35)
        self.assertEqual(len(RULES), 35)
        for example in SCENARIOS:
            analysis = analyze(example["model"])
            for entry in analysis["trace"]:
                self.assertIn(entry["ruleId"], rule_ids)
                self.assertTrue(entry["condition"] and entry["conclusion"])
            self.assertEqual(analysis["metrics"]["rulesFired"], len({e["ruleId"] for e in analysis["trace"]}))

    def test_28_determinism_and_independent_scenarios(self):
        self.assertEqual(analyze(base()), analyze(base()))
        copy = base()
        copy["transactions"][0]["output"] = 99
        self.assertEqual(base()["transactions"][0]["output"], 1)
        self.assertEqual(SCENARIOS[1]["model"]["transactions"][0]["output"], 1)

    def test_29_baseline_single_account_simulation(self):
        model = base()
        analysis = analyze(model)
        for transaction_id, batches, profit in (("gift-buyback", 10, 40), ("charm-buyback", 2, 8), ("cafe-orders", 3, 12)):
            result = simulate(model, route(analysis, transaction_id)["id"], 10, 24)
            self.assertEqual((result["completedBatches"], result["totalProfit"]), (batches, profit))
            self.assertEqual(result["timeline"][-1]["cumulativeProfit"], profit)
            self.assertTrue(result["verifiedWithinModel"])

    def test_30_simulation_excludes_window_endpoint(self):
        model = patch(small(), "b", cooldown=60)
        cycle = analyze(model)["cycles"][0]
        self.assertEqual(simulate(model, cycle["id"], 10, 1)["completedBatches"], 1)
        two_hours = simulate(model, cycle["id"], 10, 2)
        self.assertEqual(two_hours["completedBatches"], 2)
        self.assertEqual([p["timeMinutes"] for p in two_hours["timeline"]], [0, 0, 60])

    def test_31_daily_cap_reset(self):
        model = base()
        cycle = route(analyze(model), "charm-buyback")
        result = simulate(model, cycle["id"], 10, 48)
        self.assertEqual((result["completedBatches"], result["totalProfit"]), (4, 16))
        self.assertEqual([p["timeMinutes"] for p in result["timeline"]], [0, 0, 0, 1440, 1440])

    def test_32_cooldown_persists_across_daily_reset(self):
        model = patch(small(), "b", cooldown=2000, cap=1)
        result = simulate(model, analyze(model)["cycles"][0]["id"], 10, 72)
        self.assertEqual(result["completedBatches"], 3)
        self.assertEqual([p["timeMinutes"] for p in result["timeline"]], [0, 0, 2000, 4000])

    def test_33_simulation_respects_all_sequential_stages(self):
        model = small((1, 2), (1, 3))
        for transaction in model["transactions"]:
            transaction["cooldown"] = 40
        cycle = analyze(model)["cycles"][0]
        self.assertEqual([s["executions"] for s in cycle["steps"]], [2, 1])
        result = simulate(model, cycle["id"], 10, 1)
        self.assertEqual((result["completedBatches"], result["totalProfit"]), (1, 1))
        self.assertEqual(result["timeline"][1]["timeMinutes"], 40)

    def test_34_incomplete_batches_do_not_spend_or_pay(self):
        model = patch(small((1, 2), (1, 3)), "a", cooldown=60)
        result = simulate(model, analyze(model)["cycles"][0]["id"], 2, 1)
        for key in ("completedBatches", "seedUsed", "totalProfit"):
            self.assertEqual(result[key], 0)
        self.assertEqual(len(result["timeline"]), 1)
        self.assertEqual(result["status"], "limited")

    def test_35_batch_can_accumulate_across_resets(self):
        model = patch(small((1, 2), (1, 3)), "a", cap=1)
        cycle = analyze(model)["cycles"][0]
        self.assertEqual(cycle["accountDailyLimit"], 0)
        self.assertEqual(simulate(model, cycle["id"], 1, 24)["completedBatches"], 0)
        result = simulate(model, cycle["id"], 1, 25)
        self.assertEqual((result["completedBatches"], result["elapsedMinutes"]), (1, 1440))

    def test_36_unknown_limits_refuse_simulation(self):
        for change in ({"cap": None}, {"cooldown": None}):
            model = patch(base(), "gift-buyback", **change)
            result = simulate(model, gift(model)["id"], 10, 24)
            self.assertEqual((result["status"], result["completedBatches"], result["verifiedWithinModel"]), ("unknown", 0, False))
            self.assertIn("No profit estimate", result["reason"])
        model = patch(base(), "wish-kiosk", transferable=None)
        cycle = route(analyze(model), "charm-buyback")
        self.assertEqual(simulate(model, cycle["id"], 10, 24)["completedBatches"], 2)

    def test_37_corrected_and_removed_routes(self):
        model = base()
        finding = gift(model)
        fix = next(r for r in finding["recommendations"] if r["id"] == "align-buyback")
        corrected = apply_patch(model, fix["patch"])
        result = simulate(corrected, finding["id"], 10, 24)
        self.assertEqual((result["completedBatches"], result["totalProfit"]), (10, 0))
        removed = patch(model, "gift-buyback", enabled=False)
        self.assertEqual(simulate(removed, finding["id"], 10, 24)["status"], "no-route")

    def test_38_simulation_separate_seed_immutable_and_deterministic(self):
        model, saved = base(), base()
        finding = gift(model)
        result = simulate(model, finding["id"], 1000, 168)
        self.assertEqual((result["completedBatches"], result["seedBudget"], result["seedUsed"], result["totalProfit"]), (1000, 20000, 20000, 4000))
        self.assertEqual(len(result["timeline"]), 1001)
        self.assertEqual(result, simulate(model, finding["id"], 1000, 168))
        self.assertEqual(model, saved)

    def test_39_simulation_parameters_bounded(self):
        model = base()
        finding = gift(model)
        for batches, hours in ((0, 24), (1001, 24), (1.5, 24), ("10", 24), (10, 0), (10, 169), (10, 1.5), (True, 24), (10, False)):
            with self.assertRaises(ValueError):
                simulate(model, finding["id"], batches, hours)

    def test_40_separator_in_transaction_ids_cannot_collide(self):
        model = small()
        a, b = model["transactions"]
        model["transactions"] = [{**a, "id": "a--b"}, {**b, "id": "c"}, {**a, "id": "a", "input": 5}, {**b, "id": "b--c", "output": 8}]
        result = analyze(model)
        self.assertEqual(len(result["cycles"]), 4)
        self.assertEqual(len({c["id"] for c in result["cycles"]}), 4)
        for cycle in result["cycles"]:
            self.assertEqual(simulate(model, cycle["id"], 1, 24)["totalProfit"], cycle["profit"])

    def test_41_multiple_currency_units_preserved(self):
        model = small()
        model["items"][1].update(kind="currency", name="Star Gems")
        model["items"].reverse()
        result = analyze(model)
        self.assertEqual(len(result["cycles"]), 1)
        cycle = result["cycles"][0]
        self.assertEqual((cycle["currencyId"], cycle["currencyName"], cycle["startAmount"], cycle["endAmount"], cycle["roi"]), ("ribbon", "Star Gems", 5, 6, 20))
        fee = next(r for r in cycle["recommendations"] if r["id"] == "add-output-fee")
        self.assertIn("Star Gems", fee["description"])
        self.assertLessEqual(analyze(apply_patch(model, fee["patch"]))["cycles"][0]["profit"], 0)
        self.assertEqual(simulate(model, cycle["id"], 1, 24)["currencyName"], "Star Gems")

    def test_42_python_booleans_are_not_numeric_facts(self):
        for field in ("input", "output", "fee", "cooldown", "cap"):
            for value in (True, False):
                model = base(); model["transactions"][0][field] = value
                self.assertFalse(validate(model)["valid"], (field, value))

    def test_43_malformed_json_types_report_errors_instead_of_crashing(self):
        for model in (None, [], 12, "economy"):
            self.assertFalse(validate(model)["valid"])
        for field in ("id", "from", "to", "kind", "input", "cap", "cooldown"):
            for value in ([], {}, 10 ** 400):
                model = base(); model["transactions"][0][field] = value
                self.assertFalse(validate(model)["valid"], (field, value))

    def test_44_exact_lots_match_independent_brute_force_oracle(self):
        rng = random.Random(20261025)
        for _ in range(75):
            input_a, output_a, input_b, output_b = [rng.randint(1, 20) for _ in range(4)]
            model = small((input_a / 100, input_b / 100), (output_a / 100, output_b / 100))
            cycle = analyze(model)["cycles"][0]

            first_count = next(n for n in range(1, input_b + 1) if n * output_a % input_b == 0)
            second_count = first_count * output_a // input_b
            self.assertEqual([s["executions"] for s in cycle["steps"]], [first_count, second_count])
            self.assertAlmostEqual(cycle["profit"], (second_count * output_b - first_count * input_a) / 100)
            self.assertEqual(Fraction(first_count * output_a, 100), Fraction(second_count * input_b, 100))

    def test_45_fractional_cooldown_uses_exact_half_open_slots(self):
        model = patch(small(), "b", cooldown=0.07)
        cycle = analyze(model)["cycles"][0]
        result = simulate(model, cycle["id"], 1000, 1)
        self.assertEqual(result["completedBatches"], 858)
        self.assertEqual(result["timeline"][-1]["timeMinutes"], 59.99)
        self.assertEqual(cycle["accountDailyLimit"], 20572)


if __name__ == "__main__":
    unittest.main()
