
import copy
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

import pandas as pd
import pytest

from knime.build_workflow import CLASSIFICATION_RULES, SEVERITY_RULES, build_workflow
from knime.export_tables import export_bundle
from knime.run_workflow import _execute, compare_decisions, model_fingerprint, run_workflow
from loopguard.engine import analyze
from loopguard.tables import audit_tables

ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = json.loads((ROOT / "data/scenarios.json").read_text(encoding="utf-8"))


def evaluate_configured_rules(row, rules):

    def atom(text):
        if text == "TRUE":
            return True
        match = re.fullmatch(r'\$(\w+)\$ (=|<|>) ("[^"]*"|[0-9]+)', text)
        assert match, f"Unexpected grammar: {text}"
        field, op, literal = match.groups()
        right = json.loads(literal)
        left = row[field]
        return {"=": lambda: left == right, "<": lambda: left < right,
                ">": lambda: left > right}[op]()
    for rule in rules:
        condition, outcome = rule.split(" => ")
        if any(all(atom(term) for term in group.split(" AND "))
               for group in condition.split(" OR ")):
            return json.loads(outcome)
    raise AssertionError("Rules must be exhaustive")


@pytest.mark.parametrize("scenario", SCENARIOS, ids=lambda row: row["id"])
def test_native_rule_expressions_match_python_scenarios(scenario):
    model = scenario["model"]
    expected = {cycle["id"]: cycle for cycle in analyze(model)["cycles"]}
    for row in audit_tables(model)["facts"].to_dict("records"):
        row["knime_classification"] = evaluate_configured_rules(row, CLASSIFICATION_RULES)
        assert row["knime_classification"] == expected[row["cycle_id"]]["classification"]
        assert evaluate_configured_rules(row, SEVERITY_RULES) == expected[row["cycle_id"]]["severity"]


@pytest.mark.parametrize("changes,expected", [
    ({"profit": 0}, "break-even"),
    ({"profit": -1}, "losing-route"),
    ({"start_amount": 1000000001}, "oversized-batch"),
    ({"unknown_limits": 1}, "unverified-repeatability"),
    ({"unknown_transfers": 1}, "unverified-repeatability"),
    ({"unknown_intent": 1}, "unverified-intent"),
    ({"mixed_intent": 1}, "unverified-intent"),
    ({"all_intended": 1}, "unbounded-intended-reward"),
    ({}, "repeatable-profit"),
    ({"all_intended": 1, "bounded": 1}, "intended-reward"),
    ({"bounded": 1, "transferable_account_cap": 1}, "account-limit-risk"),
    ({"bounded": 1, "transferable_account_cap": 1, "global_cap": 1}, "bounded-arbitrage"),
])
def test_every_ordered_classification_branch(changes, expected):
    row = dict(profit=4, start_amount=20, unknown_limits=0, unknown_transfers=0,
               unknown_intent=0, mixed_intent=0, bounded=0, all_intended=0,
               transferable_account_cap=0, global_cap=0)
    row.update(changes)
    assert evaluate_configured_rules(row, CLASSIFICATION_RULES) == expected


def test_archive_has_portable_connected_nodes_and_current_facts(tmp_path):
    model = copy.deepcopy(SCENARIOS[0]["model"])
    archive = export_bundle(model, tmp_path)
    namespace = {"k": "http://www.knime.org/2008/09/XMLConfig"}
    with zipfile.ZipFile(archive) as bundle:
        workflow = ET.fromstring(bundle.read("LoopGuard Friendship Fair/workflow.knime"))
        nodes = workflow.find("k:config[@key='nodes']", namespace)
        connections = workflow.find("k:config[@key='connections']", namespace)
        assert len(nodes) == 4 and len(connections) == 3
        manifest = json.loads(bundle.read("LoopGuard Friendship Fair/data/manifest.json"))
        assert manifest["fingerprint"] == model_fingerprint(model)
        for name in bundle.namelist():
            if name.endswith(".xml"):
                settings = bundle.read(name).decode("utf-8")
                assert "C:\\Users" not in settings
                ET.fromstring(settings)
        facts = pd.read_csv(bundle.open("LoopGuard Friendship Fair/data/cycle_facts.csv"))
        assert len(facts) == 6


def test_fingerprint_changes_with_policy():
    model = copy.deepcopy(SCENARIOS[0]["model"])
    original = model_fingerprint(model)
    model["transactions"][0]["input"] = float(model["transactions"][0]["input"])
    assert model_fingerprint(model) == original
    model["transactions"][0]["cap"] = None
    assert model_fingerprint(model) != original


def test_empty_model_does_not_claim_knime_was_executed():
    model = copy.deepcopy(SCENARIOS[0]["model"])
    for trade in model["transactions"]:
        trade["enabled"] = False
    result = run_workflow(model)
    assert result["status"] == "empty" and result["executed"] is False
    assert result["matched"] is None


def test_manual_comparison_rejects_stale_and_duplicate_results():
    model = copy.deepcopy(SCENARIOS[0]["model"])
    frame = audit_tables(model)["cycles"][["cycle_id", "classification", "severity"]].rename(
        columns={"classification": "knime_classification", "severity": "knime_severity"})
    frame["model_fingerprint"] = model_fingerprint(model)
    assert compare_decisions(model, frame)["matches"].all()
    with pytest.raises(ValueError, match="duplicate"):
        compare_decisions(model, pd.concat([frame, frame.iloc[:1]]))
    frame.loc[0, "knime_classification"] = "wrong-decision"
    assert not compare_decisions(model, frame)["matches"].all()
    model["transactions"][0]["cap"] = None
    with pytest.raises(ValueError, match="different economy revision"):
        compare_decisions(model, frame)


def test_executor_captures_failure_and_times_out_its_own_process():
    code, output = _execute([sys.executable, "-c", "print('specific failure'); raise SystemExit(7)"], 10)
    assert code == 7 and "specific failure" in output
    with pytest.raises(RuntimeError, match="produced no accepted result"):
        _execute([sys.executable, "-c", "import time; time.sleep(30)"], 1)
